package androidx.media3.exoplayer.mediacodec;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class MediaCodecPerformancePointCoverageProvider$Api29$$ExternalSyntheticApiModelOutline1 {
    public static /* synthetic */ android.media.MediaCodecInfo.VideoCapabilities.PerformancePoint m(int i, int i2, int i3) {
        return new android.media.MediaCodecInfo.VideoCapabilities.PerformancePoint(i, i2, i3);
    }
}
