package androidx.media3.exoplayer;

import android.media.MediaFormat;
import android.os.Bundle;
import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public final class CodecParameters {
    public static final CodecParameters EMPTY = new Builder().build();
    private final Map params;

    private CodecParameters(Map map) {
        this.params = Collections.unmodifiableMap(map);
    }

    public Builder buildUpon() {
        return new Builder();
    }

    public static final class Builder {
        private final Map params;

        public Builder() {
            this.params = new HashMap();
        }

        private Builder(CodecParameters codecParameters) {
            this.params = new HashMap(codecParameters.params);
        }

        public Builder setInteger(String str, int i) {
            this.params.put(str, Integer.valueOf(i));
            return this;
        }

        public Builder setLong(String str, long j) {
            this.params.put(str, Long.valueOf(j));
            return this;
        }

        public Builder setFloat(String str, float f) {
            this.params.put(str, Float.valueOf(f));
            return this;
        }

        public Builder setString(String str, String str2) {
            this.params.put(str, str2);
            return this;
        }

        public Builder setByteBuffer(String str, ByteBuffer byteBuffer) {
            if (byteBuffer == null) {
                this.params.put(str, null);
                return this;
            }
            ByteBuffer byteBufferAllocate = ByteBuffer.allocate(byteBuffer.remaining());
            byteBufferAllocate.put(byteBuffer.duplicate());
            byteBufferAllocate.flip();
            this.params.put(str, byteBufferAllocate);
            return this;
        }

        public Builder remove(String str) {
            this.params.remove(str);
            return this;
        }

        public CodecParameters build() {
            return new CodecParameters(this.params);
        }
    }

    public static Builder createFrom(MediaFormat mediaFormat, Set set) {
        Builder builder = new Builder();
        Iterator it = set.iterator();
        while (it.hasNext()) {
            String str = (String) it.next();
            if (mediaFormat.containsKey(str)) {
                int valueTypeForKey = mediaFormat.getValueTypeForKey(str);
                if (valueTypeForKey == 1) {
                    builder.setInteger(str, mediaFormat.getInteger(str));
                } else if (valueTypeForKey == 2) {
                    builder.setLong(str, mediaFormat.getLong(str));
                } else if (valueTypeForKey == 3) {
                    builder.setFloat(str, mediaFormat.getFloat(str));
                } else if (valueTypeForKey == 4) {
                    builder.setString(str, mediaFormat.getString(str));
                } else if (valueTypeForKey == 5) {
                    builder.setByteBuffer(str, mediaFormat.getByteBuffer(str));
                }
            }
        }
        return builder;
    }

    public Set keySet() {
        return this.params.keySet();
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof CodecParameters) {
            return this.params.equals(((CodecParameters) obj).params);
        }
        return false;
    }

    public int hashCode() {
        return this.params.hashCode();
    }

    public Bundle toBundle() {
        Bundle bundle = new Bundle();
        for (Map.Entry entry : this.params.entrySet()) {
            String str = (String) entry.getKey();
            Object value = entry.getValue();
            if (value != null) {
                if (value instanceof Integer) {
                    bundle.putInt(str, ((Integer) value).intValue());
                } else if (value instanceof Long) {
                    bundle.putLong(str, ((Long) value).longValue());
                } else if (value instanceof Float) {
                    bundle.putFloat(str, ((Float) value).floatValue());
                } else if (value instanceof String) {
                    bundle.putString(str, (String) value);
                } else if (value instanceof ByteBuffer) {
                    ByteBuffer byteBuffer = (ByteBuffer) value;
                    byte[] bArr = new byte[byteBuffer.remaining()];
                    byteBuffer.duplicate().get(bArr);
                    bundle.putByteArray(str, bArr);
                }
            }
        }
        return bundle;
    }

    public void applyTo(MediaFormat mediaFormat) {
        for (Map.Entry entry : this.params.entrySet()) {
            String str = (String) entry.getKey();
            Object value = entry.getValue();
            if (value == null) {
                mediaFormat.setString(str, null);
            } else if (value instanceof Integer) {
                mediaFormat.setInteger(str, ((Integer) value).intValue());
            } else if (value instanceof Long) {
                mediaFormat.setLong(str, ((Long) value).longValue());
            } else if (value instanceof Float) {
                mediaFormat.setFloat(str, ((Float) value).floatValue());
            } else if (value instanceof String) {
                mediaFormat.setString(str, (String) value);
            } else if (value instanceof ByteBuffer) {
                mediaFormat.setByteBuffer(str, (ByteBuffer) value);
            }
        }
    }
}
