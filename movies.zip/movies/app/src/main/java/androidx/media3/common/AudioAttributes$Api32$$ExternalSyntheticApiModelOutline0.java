package androidx.media3.common;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class AudioAttributes$Api32$$ExternalSyntheticApiModelOutline0 {
}
