package androidx.media3.common.util;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class NetworkTypeObserver$Api31$$ExternalSyntheticApiModelOutline0 {
}
