package androidx.media3.exoplayer;

import android.content.Context;
import android.media.MediaDataSource;
import android.media.MediaFormat;
import androidx.media3.common.ParserException;
import androidx.media3.datasource.DataSource;
import androidx.media3.datasource.DefaultDataSource;
import androidx.media3.extractor.DefaultExtractorsFactory;
import androidx.media3.extractor.ExtractorsFactory;
import java.nio.ByteBuffer;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public final class MediaExtractorCompat {
    private final MediaExtractorCompatInternal delegate;

    public MediaExtractorCompat(Context context) {
        this(new DefaultExtractorsFactory(), new DefaultDataSource.Factory(context));
    }

    public MediaExtractorCompat(ExtractorsFactory extractorsFactory, DataSource.Factory factory) {
        this.delegate = new MediaExtractorCompatInternal(extractorsFactory, factory);
    }

    public void setDataSource(String str) throws ParserException {
        this.delegate.setDataSource(str);
    }

    public void setDataSource(String str, Map map) throws ParserException {
        this.delegate.setDataSource(str, map);
    }

    public void setDataSource(MediaDataSource mediaDataSource) throws ParserException {
        this.delegate.setDataSource(mediaDataSource);
    }

    public void release() {
        this.delegate.release();
    }

    public int getTrackCount() {
        return this.delegate.getTrackCount();
    }

    public MediaFormat getTrackFormat(int i) {
        return this.delegate.getTrackFormat(i);
    }

    public void selectTrack(int i) {
        this.delegate.selectTrack(i);
    }

    public void unselectTrack(int i) {
        this.delegate.unselectTrack(i);
    }

    public void seekTo(long j, int i) {
        this.delegate.seekTo(j, i);
    }

    public boolean advance() {
        return this.delegate.advance();
    }

    public int readSampleData(ByteBuffer byteBuffer, int i) {
        return this.delegate.readSampleData(byteBuffer, i);
    }

    public long getSampleTime() {
        return this.delegate.getSampleTime();
    }
}
