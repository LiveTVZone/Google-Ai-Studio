package androidx.media3.common.text;

import android.os.Bundle;
import androidx.media3.common.util.Util;
import com.google.common.base.Preconditions;

/* JADX INFO: loaded from: classes.dex */
public final class VoiceSpan {
    private static final String FIELD_NAME = Util.intToStringMaxRadix(0);
    public final String name;

    public VoiceSpan(String str) {
        this.name = str;
    }

    public Bundle toBundle() {
        Bundle bundle = new Bundle();
        bundle.putString(FIELD_NAME, this.name);
        return bundle;
    }

    public static VoiceSpan fromBundle(Bundle bundle) {
        return new VoiceSpan((String) Preconditions.checkNotNull(bundle.getString(FIELD_NAME)));
    }
}
