package androidx.media3.exoplayer;

import android.media.MediaRoute2Info;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class DefaultSuitableOutputChecker$ImplApi35$$ExternalSyntheticApiModelOutline14 {
    public static /* bridge */ /* synthetic */ MediaRoute2Info m(Object obj) {
        return (MediaRoute2Info) obj;
    }
}
