package androidx.media3.exoplayer.mediacodec;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class MediaCodecPerformancePointCoverageProvider$Api29$$ExternalSyntheticApiModelOutline0 {
}
