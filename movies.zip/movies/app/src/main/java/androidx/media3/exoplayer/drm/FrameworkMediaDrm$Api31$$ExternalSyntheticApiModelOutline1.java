package androidx.media3.exoplayer.drm;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class FrameworkMediaDrm$Api31$$ExternalSyntheticApiModelOutline1 {
}
