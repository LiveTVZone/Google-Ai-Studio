package androidx.media3.exoplayer.source;

import androidx.media3.exoplayer.LoadingInfo;

/* JADX INFO: loaded from: classes.dex */
public interface SequenceableLoader {

    public interface Callback {
        void onContinueLoadingRequested(SequenceableLoader sequenceableLoader);
    }

    boolean continueLoading(LoadingInfo loadingInfo);

    long getBufferedPositionUs();

    long getNextLoadPositionUs();

    boolean isLoading();

    void reevaluateBuffer(long j);
}
