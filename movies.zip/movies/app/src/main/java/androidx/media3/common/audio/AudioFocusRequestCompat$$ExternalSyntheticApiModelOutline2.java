package androidx.media3.common.audio;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class AudioFocusRequestCompat$$ExternalSyntheticApiModelOutline2 {
}
