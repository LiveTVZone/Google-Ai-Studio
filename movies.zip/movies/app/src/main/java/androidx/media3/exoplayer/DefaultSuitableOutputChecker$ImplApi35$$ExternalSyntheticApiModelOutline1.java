package androidx.media3.exoplayer;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class DefaultSuitableOutputChecker$ImplApi35$$ExternalSyntheticApiModelOutline1 {
    public static /* synthetic */ void m() {
    }
}
