package androidx.media3.exoplayer.audio;

import android.media.AudioProfile;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class AudioCapabilities$$ExternalSyntheticApiModelOutline0 {
    public static /* bridge */ /* synthetic */ AudioProfile m(Object obj) {
        return (AudioProfile) obj;
    }
}
