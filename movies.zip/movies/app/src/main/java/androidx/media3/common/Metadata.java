package androidx.media3.common;

import androidx.media3.common.util.Util;
import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import com.google.common.collect.ImmutableList;
import com.google.common.primitives.Longs;
import java.util.Arrays;
import java.util.List;
import mov.film.Channel;

/* JADX INFO: loaded from: classes.dex */
public final class Metadata {
    private final Entry[] entries;
    public final long presentationTimeUs;

    public interface Entry {
        default byte[] getWrappedMetadataBytes() {
            return null;
        }

        default Format getWrappedMetadataFormat() {
            return null;
        }

        default void populateMediaMetadata(MediaMetadata.Builder builder) {
        }
    }

    public Metadata(Entry... entryArr) {
        this(-9223372036854775807L, entryArr);
    }

    public Metadata(long j, Entry... entryArr) {
        this.presentationTimeUs = j;
        this.entries = entryArr;
    }

    public Metadata(List list) {
        this((Entry[]) list.toArray(new Entry[0]));
    }

    public Metadata(long j, List list) {
        this(j, (Entry[]) list.toArray(new Entry[0]));
    }

    public int length() {
        return this.entries.length;
    }

    public Entry get(int i) {
        return this.entries[i];
    }

    public Entry getFirstEntryOfType(Class cls) {
        return getFirstMatchingEntry(cls, Predicates.alwaysTrue());
    }

    public Entry getFirstMatchingEntry(Class cls, Predicate predicate) {
        for (Entry entry : this.entries) {
            Entry entryEntryIfMatches = entryIfMatches(entry, cls, predicate);
            if (entryEntryIfMatches != null) {
                return entryEntryIfMatches;
            }
        }
        return null;
    }

    public ImmutableList getEntriesOfType(Class cls) {
        ImmutableList.Builder builder = ImmutableList.builder();
        for (Entry entry : this.entries) {
            if (cls.isAssignableFrom(entry.getClass())) {
                builder.add(cls.cast(entry));
            }
        }
        return builder.build();
    }

    public ImmutableList getMatchingEntries(Class cls, Predicate predicate) {
        ImmutableList.Builder builder = ImmutableList.builder();
        for (Entry entry : this.entries) {
            Entry entryEntryIfMatches = entryIfMatches(entry, cls, predicate);
            if (entryEntryIfMatches != null) {
                builder.add((Object) entryEntryIfMatches);
            }
        }
        return builder.build();
    }

    private Entry entryIfMatches(Entry entry, Class cls, Predicate predicate) {
        if (!cls.isAssignableFrom(entry.getClass())) {
            return null;
        }
        Entry entry2 = (Entry) cls.cast(entry);
        if (predicate.apply(entry2)) {
            return entry2;
        }
        return null;
    }

    public Metadata copyWithAppendedEntriesFrom(Metadata metadata) {
        return metadata == null ? this : copyWithAppendedEntries(metadata.entries);
    }

    public Metadata copyWithAppendedEntries(Entry... entryArr) {
        return entryArr.length == 0 ? this : new Metadata(this.presentationTimeUs, (Entry[]) Util.nullSafeArrayConcatenation(this.entries, entryArr));
    }

    public Metadata copyWithPresentationTimeUs(long j) {
        return this.presentationTimeUs == j ? this : new Metadata(j, this.entries);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && Metadata.class == obj.getClass()) {
            Metadata metadata = (Metadata) obj;
            if (Arrays.equals(this.entries, metadata.entries) && this.presentationTimeUs == metadata.presentationTimeUs) {
                return true;
            }
        }
        return false;
    }

    public int hashCode() {
        return (Arrays.hashCode(this.entries) * 31) + Longs.hashCode(this.presentationTimeUs);
    }

    public String toString() {
        String str;
        StringBuilder sb = new StringBuilder();
        sb.append("entries=");
        sb.append(Arrays.toString(this.entries));
        if (this.presentationTimeUs == -9223372036854775807L) {
            str = Channel.MOVE_BY;
        } else {
            str = ", presentationTimeUs=" + this.presentationTimeUs;
        }
        sb.append(str);
        return sb.toString();
    }
}
