package androidx.media3.exoplayer.analytics;

import android.media.metrics.PlaybackStateEvent;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class MediaMetricsListener$$ExternalSyntheticApiModelOutline4 {
    public static /* synthetic */ PlaybackStateEvent.Builder m() {
        return new PlaybackStateEvent.Builder();
    }
}
