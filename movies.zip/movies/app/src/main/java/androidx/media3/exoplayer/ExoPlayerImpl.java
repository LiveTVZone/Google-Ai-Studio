package androidx.media3.exoplayer;

import android.content.Context;
import android.graphics.Rect;
import android.graphics.SurfaceTexture;
import android.media.MediaFormat;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Pair;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.TextureView;
import androidx.media3.common.AudioAttributes;
import androidx.media3.common.BasePlayer;
import androidx.media3.common.DeviceInfo;
import androidx.media3.common.FlagSet;
import androidx.media3.common.Format;
import androidx.media3.common.IllegalSeekPositionException;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaLibraryInfo;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.Metadata;
import androidx.media3.common.MimeTypes$$ExternalSyntheticThrowCCEIfNotNull0;
import androidx.media3.common.PlaybackParameters;
import androidx.media3.common.Player;
import androidx.media3.common.Timeline;
import androidx.media3.common.TrackSelectionParameters;
import androidx.media3.common.Tracks;
import androidx.media3.common.VideoSize;
import androidx.media3.common.audio.AudioBecomingNoisyManager;
import androidx.media3.common.text.CueGroup;
import androidx.media3.common.util.BackgroundThreadStateHandler;
import androidx.media3.common.util.Clock;
import androidx.media3.common.util.ConditionVariable;
import androidx.media3.common.util.HandlerWrapper;
import androidx.media3.common.util.ListenerSet;
import androidx.media3.common.util.Log;
import androidx.media3.common.util.Size;
import androidx.media3.common.util.StuckPlayerDetector;
import androidx.media3.common.util.StuckPlayerException;
import androidx.media3.common.util.Util;
import androidx.media3.common.util.WakeLockManager;
import androidx.media3.common.util.WifiLockManager;
import androidx.media3.exoplayer.analytics.AnalyticsCollector;
import androidx.media3.exoplayer.analytics.AnalyticsListener;
import androidx.media3.exoplayer.analytics.MediaMetricsListener;
import androidx.media3.exoplayer.analytics.PlayerId;
import androidx.media3.exoplayer.audio.AudioRendererEventListener;
import androidx.media3.exoplayer.audio.AudioSink;
import androidx.media3.exoplayer.metadata.MetadataOutput;
import androidx.media3.exoplayer.source.MaskingMediaSource;
import androidx.media3.exoplayer.source.MediaSource;
import androidx.media3.exoplayer.source.ShuffleOrder;
import androidx.media3.exoplayer.source.TrackGroupArray;
import androidx.media3.exoplayer.text.TextOutput;
import androidx.media3.exoplayer.trackselection.ExoTrackSelection;
import androidx.media3.exoplayer.trackselection.TrackSelector;
import androidx.media3.exoplayer.trackselection.TrackSelectorResult;
import androidx.media3.exoplayer.upstream.BandwidthMeter;
import androidx.media3.exoplayer.video.VideoFrameMetadataListener;
import androidx.media3.exoplayer.video.VideoRendererEventListener;
import androidx.media3.exoplayer.video.spherical.CameraMotionListener;
import com.google.common.base.Function;
import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.UnmodifiableIterator;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.function.IntConsumer;

/* JADX INFO: loaded from: classes.dex */
final class ExoPlayerImpl extends BasePlayer implements ExoPlayer {
    private final AnalyticsCollector analyticsCollector;
    private final Context applicationContext;
    private final Looper applicationLooper;
    private AudioAttributes audioAttributes;
    private final AudioBecomingNoisyManager audioBecomingNoisyManager;
    private DecoderCounters audioDecoderCounters;
    private Format audioFormat;
    private final CodecParameterListenerManager audioListenerManager;
    private final CopyOnWriteArraySet audioOffloadListeners;
    private final BackgroundThreadStateHandler audioSessionIdState;
    private Player.Commands availableCommands;
    private final BandwidthMeter bandwidthMeter;
    private final Clock clock;
    private final ComponentListener componentListener;
    private final ConditionVariable constructorFinished = new ConditionVariable();
    private CueGroup currentCueGroup;
    private final long detachSurfaceTimeoutMs;
    private DeviceInfo deviceInfo;
    private ImmutableSet disabledTrackTypesWithoutScrubbingMode;
    final TrackSelectorResult emptyTrackSelectorResult;
    private final FrameMetadataListener frameMetadataListener;
    private boolean hasNotifiedFullWrongThreadWarning;
    private final ExoPlayerImplInternal internalPlayer;
    private boolean isPriorityTaskManagerRegistered;
    private final ListenerSet listeners;
    private int maskingWindowIndex;
    private long maskingWindowPositionMs;
    private long maxSeekToPreviousPositionMs;
    private MediaMetadata mediaMetadata;
    private final MediaSource.Factory mediaSourceFactory;
    private final List mediaSourceHolderSnapshots;
    private Surface ownedSurface;
    private boolean pauseAtEndOfMediaItems;
    private boolean pendingDiscontinuity;
    private int pendingDiscontinuityReason;
    private int pendingOperationAcks;
    private final Timeline.Period period;
    final Player.Commands permanentAvailableCommands;
    private PlaybackInfo playbackInfo;
    private final HandlerWrapper playbackInfoUpdateHandler;
    private final ExoPlayerImplInternal.PlaybackInfoUpdateListener playbackInfoUpdateListener;
    private boolean playerReleased;
    private MediaMetadata playlistMetadata;
    private ExoPlayer.PreloadConfiguration preloadConfiguration;
    private int priority;
    private final Renderer[] renderers;
    private int repeatMode;
    private boolean scrubbingModeEnabled;
    private ScrubbingModeParameters scrubbingModeParameters;
    private final Renderer[] secondaryRenderers;
    private long seekBackIncrementMs;
    private long seekForwardIncrementMs;
    private SeekParameters seekParameters;
    private boolean shuffleModeEnabled;
    private ShuffleOrder shuffleOrder;
    private boolean skipSilenceEnabled;
    private MediaMetadata staticAndDynamicMediaMetadata;
    private final StreamVolumeManager streamVolumeManager;
    private final StuckPlayerDetector stuckPlayerDetector;
    private final SuitableOutputChecker suitableOutputChecker;
    private SurfaceHolder surfaceHolder;
    private boolean surfaceHolderSurfaceIsVideoOutput;
    private Size surfaceSize;
    private TextureView textureView;
    private boolean throwsWhenUsingWrongThread;
    private final TrackSelector trackSelector;
    private final boolean useLazyPreparation;
    private int videoChangeFrameRateStrategy;
    private DecoderCounters videoDecoderCounters;
    private Format videoFormat;
    private final CodecParameterListenerManager videoListenerManager;
    private Object videoOutput;
    private int videoScalingMode;
    private VideoSize videoSize;
    private final VirtualDeviceIdChangeListener virtualDeviceIdChangeListener;
    private float volume;
    private final WakeLockManager wakeLockManager;
    private final WifiLockManager wifiLockManager;
    private final Player wrappingPlayer;

    private void updatePriorityTaskManagerForIsLoadingChange(boolean z) {
    }

    static {
        MediaLibraryInfo.registerModule("media3.exoplayer");
    }

    public ExoPlayerImpl(ExoPlayer.Builder builder, Player player) {
        Clock clock;
        try {
            Log.i("ExoPlayerImpl", "Init " + Integer.toHexString(System.identityHashCode(this)) + " [AndroidXMedia3/1.9.0] [" + Util.DEVICE_DEBUG_INFO + "]");
            this.applicationContext = builder.context.getApplicationContext();
            this.analyticsCollector = (AnalyticsCollector) builder.analyticsCollectorFunction.apply(builder.clock);
            this.priority = builder.priority;
            this.audioAttributes = builder.audioAttributes;
            this.videoScalingMode = builder.videoScalingMode;
            this.videoChangeFrameRateStrategy = builder.videoChangeFrameRateStrategy;
            this.skipSilenceEnabled = builder.skipSilenceEnabled;
            this.detachSurfaceTimeoutMs = builder.detachSurfaceTimeoutMs;
            ComponentListener componentListener = new ComponentListener();
            this.componentListener = componentListener;
            this.frameMetadataListener = new FrameMetadataListener();
            Handler handler = new Handler(builder.looper);
            RenderersFactory renderersFactory = (RenderersFactory) builder.renderersFactorySupplier.get();
            Renderer[] rendererArrCreateRenderers = renderersFactory.createRenderers(handler, componentListener, componentListener, componentListener, componentListener);
            this.renderers = rendererArrCreateRenderers;
            Preconditions.checkState(rendererArrCreateRenderers.length > 0);
            this.secondaryRenderers = new Renderer[rendererArrCreateRenderers.length];
            int i = 0;
            while (true) {
                Renderer[] rendererArr = this.secondaryRenderers;
                if (i >= rendererArr.length) {
                    break;
                }
                Renderer renderer = this.renderers[i];
                ComponentListener componentListener2 = this.componentListener;
                rendererArr[i] = renderersFactory.createSecondaryRenderer(renderer, handler, componentListener2, componentListener2, componentListener2, componentListener2);
                i++;
            }
            TrackSelector trackSelector = (TrackSelector) builder.trackSelectorSupplier.get();
            this.trackSelector = trackSelector;
            this.mediaSourceFactory = (MediaSource.Factory) builder.mediaSourceFactorySupplier.get();
            BandwidthMeter bandwidthMeter = (BandwidthMeter) builder.bandwidthMeterSupplier.get();
            this.bandwidthMeter = bandwidthMeter;
            this.useLazyPreparation = builder.useLazyPreparation;
            this.seekParameters = builder.seekParameters;
            this.seekBackIncrementMs = builder.seekBackIncrementMs;
            this.seekForwardIncrementMs = builder.seekForwardIncrementMs;
            this.maxSeekToPreviousPositionMs = builder.maxSeekToPreviousPositionMs;
            this.scrubbingModeParameters = builder.scrubbingModeParameters;
            this.pauseAtEndOfMediaItems = builder.pauseAtEndOfMediaItems;
            Looper looper = builder.looper;
            this.applicationLooper = looper;
            Clock clock2 = builder.clock;
            this.clock = clock2;
            Player player2 = player == null ? this : player;
            this.wrappingPlayer = player2;
            this.listeners = new ListenerSet(looper, clock2, new ListenerSet.IterationFinishedEvent() { // from class: androidx.media3.exoplayer.ExoPlayerImpl$$ExternalSyntheticLambda16
                @Override // androidx.media3.common.util.ListenerSet.IterationFinishedEvent
                public final void invoke(Object obj, FlagSet flagSet) {
                    ((Player.Listener) obj).onEvents(this.f$0.wrappingPlayer, new Player.Events(flagSet));
                }
            });
            this.audioOffloadListeners = new CopyOnWriteArraySet();
            this.mediaSourceHolderSnapshots = new ArrayList();
            this.shuffleOrder = new ShuffleOrder.DefaultShuffleOrder(0);
            this.preloadConfiguration = ExoPlayer.PreloadConfiguration.DEFAULT;
            Renderer[] rendererArr2 = this.renderers;
            TrackSelectorResult trackSelectorResult = new TrackSelectorResult(new RendererConfiguration[rendererArr2.length], new ExoTrackSelection[rendererArr2.length], Tracks.EMPTY, null);
            this.emptyTrackSelectorResult = trackSelectorResult;
            this.period = new Timeline.Period();
            Player.Commands commandsBuild = new Player.Commands.Builder().addAll(1, 2, 3, 13, 14, 15, 16, 17, 18, 19, 31, 20, 30, 21, 35, 22, 24, 27, 28, 32).addIf(29, trackSelector.isSetParametersSupported()).addIf(23, builder.deviceVolumeControlEnabled).addIf(25, builder.deviceVolumeControlEnabled).addIf(33, builder.deviceVolumeControlEnabled).addIf(26, builder.deviceVolumeControlEnabled).addIf(34, builder.deviceVolumeControlEnabled).build();
            this.permanentAvailableCommands = commandsBuild;
            this.availableCommands = new Player.Commands.Builder().addAll(commandsBuild).add(4).add(10).build();
            this.playbackInfoUpdateHandler = clock2.createHandler(looper, null);
            ExoPlayerImplInternal.PlaybackInfoUpdateListener playbackInfoUpdateListener = new ExoPlayerImplInternal.PlaybackInfoUpdateListener() { // from class: androidx.media3.exoplayer.ExoPlayerImpl$$ExternalSyntheticLambda17
                @Override // androidx.media3.exoplayer.ExoPlayerImplInternal.PlaybackInfoUpdateListener
                public final void onPlaybackInfoUpdate(ExoPlayerImplInternal.PlaybackInfoUpdate playbackInfoUpdate) {
                    ExoPlayerImpl exoPlayerImpl = this.f$0;
                    exoPlayerImpl.playbackInfoUpdateHandler.post(new Runnable() { // from class: androidx.media3.exoplayer.ExoPlayerImpl$$ExternalSyntheticLambda22
                        @Override // java.lang.Runnable
                        public final void run() {
                            exoPlayerImpl.handlePlaybackInfo(playbackInfoUpdate);
                        }
                    });
                }
            };
            this.playbackInfoUpdateListener = playbackInfoUpdateListener;
            this.playbackInfo = PlaybackInfo.createDummy(trackSelectorResult);
            this.analyticsCollector.setPlayer(player2, looper);
            PlayerId playerId = new PlayerId(builder.playerName);
            ExoPlayerImplInternal exoPlayerImplInternal = new ExoPlayerImplInternal(this.applicationContext, this.renderers, this.secondaryRenderers, trackSelector, trackSelectorResult, (LoadControl) builder.loadControlSupplier.get(), bandwidthMeter, this.repeatMode, this.shuffleModeEnabled, this.analyticsCollector, this.seekParameters, builder.livePlaybackSpeedControl, builder.releaseTimeoutMs, this.pauseAtEndOfMediaItems, builder.dynamicSchedulingEnabled, looper, clock2, playbackInfoUpdateListener, playerId, builder.playbackLooperProvider, this.preloadConfiguration, this.frameMetadataListener);
            this.internalPlayer = exoPlayerImplInternal;
            Looper playbackLooper = exoPlayerImplInternal.getPlaybackLooper();
            this.volume = 1.0f;
            this.repeatMode = 0;
            MediaMetadata mediaMetadata = MediaMetadata.EMPTY;
            this.mediaMetadata = mediaMetadata;
            this.playlistMetadata = mediaMetadata;
            this.staticAndDynamicMediaMetadata = mediaMetadata;
            this.maskingWindowIndex = -1;
            this.currentCueGroup = CueGroup.EMPTY_TIME_ZERO;
            this.throwsWhenUsingWrongThread = true;
            addListener(this.analyticsCollector);
            bandwidthMeter.addEventListener(new Handler(looper), this.analyticsCollector);
            addAudioOffloadListener(this.componentListener);
            long j = builder.foregroundModeTimeoutMs;
            if (j > 0) {
                exoPlayerImplInternal.experimentalSetForegroundModeTimeoutMs(j);
            }
            int i2 = Build.VERSION.SDK_INT;
            if (i2 >= 31) {
                Api31.registerMediaMetricsListener(this.applicationContext, this, builder.usePlatformDiagnostics, playerId);
            }
            BackgroundThreadStateHandler backgroundThreadStateHandler = new BackgroundThreadStateHandler(0, playbackLooper, looper, clock2, new BackgroundThreadStateHandler.StateChangeListener() { // from class: androidx.media3.exoplayer.ExoPlayerImpl$$ExternalSyntheticLambda18
                @Override // androidx.media3.common.util.BackgroundThreadStateHandler.StateChangeListener
                public final void onStateChanged(Object obj, Object obj2) {
                    this.f$0.onAudioSessionIdChanged(((Integer) obj).intValue(), ((Integer) obj2).intValue());
                }
            });
            this.audioSessionIdState = backgroundThreadStateHandler;
            backgroundThreadStateHandler.runInBackground(new Runnable() { // from class: androidx.media3.exoplayer.ExoPlayerImpl$$ExternalSyntheticLambda19
                @Override // java.lang.Runnable
                public final void run() {
                    ExoPlayerImpl exoPlayerImpl = this.f$0;
                    exoPlayerImpl.audioSessionIdState.setStateInBackground(Integer.valueOf(Util.generateAudioSessionIdV21(exoPlayerImpl.applicationContext)));
                }
            });
            AudioBecomingNoisyManager audioBecomingNoisyManager = new AudioBecomingNoisyManager(builder.context, playbackLooper, builder.looper, this.componentListener, clock2);
            Clock clock3 = clock2;
            this.audioBecomingNoisyManager = audioBecomingNoisyManager;
            audioBecomingNoisyManager.setEnabled(builder.handleAudioBecomingNoisy);
            if (builder.suppressPlaybackOnUnsuitableOutput) {
                SuitableOutputChecker suitableOutputChecker = builder.suitableOutputChecker;
                this.suitableOutputChecker = suitableOutputChecker;
                suitableOutputChecker.enable(new SuitableOutputChecker.Callback() { // from class: androidx.media3.exoplayer.ExoPlayerImpl$$ExternalSyntheticLambda20
                    @Override // androidx.media3.exoplayer.SuitableOutputChecker.Callback
                    public final void onSelectedOutputSuitabilityChanged(boolean z) {
                        this.f$0.onSelectedOutputSuitabilityChanged(z);
                    }
                }, this.applicationContext, looper, playbackLooper, clock3);
                clock3 = clock3;
            } else {
                this.suitableOutputChecker = null;
            }
            if (builder.deviceVolumeControlEnabled) {
                Clock clock4 = clock3;
                clock = clock4;
                this.streamVolumeManager = new StreamVolumeManager(builder.context, this.componentListener, this.audioAttributes.getStreamType(), playbackLooper, looper, clock4);
            } else {
                clock = clock3;
                this.streamVolumeManager = null;
            }
            int i3 = builder.wakeModeSet ? builder.wakeMode : (builder.stuckBufferingDetectionTimeoutMs == Integer.MAX_VALUE || builder.stuckPlayingDetectionTimeoutMs == Integer.MAX_VALUE || builder.stuckPlayingNotEndingTimeoutMs == Integer.MAX_VALUE || builder.stuckSuppressedDetectionTimeoutMs == Integer.MAX_VALUE) ? 0 : 1;
            WakeLockManager wakeLockManager = new WakeLockManager(builder.context, 
            /*  JADX ERROR: Method code generation error
                jadx.core.utils.exceptions.CodegenException: Error generate insn: 0x0329: CONSTRUCTOR (r5v14 'wakeLockManager' androidx.media3.common.util.WakeLockManager) = 
                  (wrap android.content.Context:0x0327: IGET (r38v0 'builder' androidx.media3.exoplayer.ExoPlayer$Builder) A[Catch: all -> 0x00c6, WRAPPED] androidx.media3.exoplayer.ExoPlayer.Builder.context android.content.Context)
                  (r16v6 ?? I:??[OBJECT, ARRAY])
                  (r2v27 'clock' androidx.media3.common.util.Clock)
                 A[Catch: all -> 0x00c6, DECLARE_VAR, MD:(android.content.Context, android.os.Looper, androidx.media3.common.util.Clock):void (m)] (LINE:472) call: androidx.media3.common.util.WakeLockManager.<init>(android.content.Context, android.os.Looper, androidx.media3.common.util.Clock):void type: CONSTRUCTOR in method: androidx.media3.exoplayer.ExoPlayerImpl.<init>(androidx.media3.exoplayer.ExoPlayer$Builder, androidx.media3.common.Player):void, file: classes.dex
                	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:310)
                	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:273)
                	at jadx.core.codegen.RegionGen.makeSimpleBlock(RegionGen.java:94)
                	at jadx.core.dex.nodes.IBlock.generate(IBlock.java:15)
                	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                	at jadx.core.dex.regions.Region.generate(Region.java:35)
                	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                	at jadx.core.codegen.RegionGen.makeRegionIndent(RegionGen.java:83)
                	at jadx.core.codegen.RegionGen.makeTryCatch(RegionGen.java:320)
                	at jadx.core.dex.regions.TryCatchRegion.generate(TryCatchRegion.java:85)
                	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                	at jadx.core.dex.regions.Region.generate(Region.java:35)
                	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                	at jadx.core.codegen.MethodGen.addRegionInsns(MethodGen.java:291)
                	at jadx.core.codegen.MethodGen.addInstructions(MethodGen.java:270)
                	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:420)
                	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:345)
                	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$2(ClassGen.java:299)
                	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(Unknown Source)
                	at java.base/java.util.ArrayList.forEach(Unknown Source)
                	at java.base/java.util.stream.SortedOps$RefSortingSink.end(Unknown Source)
                	at java.base/java.util.stream.Sink$ChainedReference.end(Unknown Source)
                	at java.base/java.util.stream.ReferencePipeline$7$1FlatMap.end(Unknown Source)
                	at java.base/java.util.stream.AbstractPipeline.copyInto(Unknown Source)
                	at java.base/java.util.stream.AbstractPipeline.wrapAndCopyInto(Unknown Source)
                	at java.base/java.util.stream.ForEachOps$ForEachOp.evaluateSequential(Unknown Source)
                	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.evaluateSequential(Unknown Source)
                	at java.base/java.util.stream.AbstractPipeline.evaluate(Unknown Source)
                	at java.base/java.util.stream.ReferencePipeline.forEach(Unknown Source)
                	at jadx.core.codegen.ClassGen.addInnerClsAndMethods(ClassGen.java:295)
                	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:284)
                	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:268)
                	at jadx.core.codegen.ClassGen.addClassCode(ClassGen.java:160)
                	at jadx.core.codegen.ClassGen.makeClass(ClassGen.java:104)
                	at jadx.core.codegen.CodeGen.wrapCodeGen(CodeGen.java:45)
                	at jadx.core.codegen.CodeGen.generateJavaCode(CodeGen.java:34)
                	at jadx.core.codegen.CodeGen.generate(CodeGen.java:22)
                	at jadx.core.ProcessClass.process(ProcessClass.java:89)
                	at jadx.core.ProcessClass.generateCode(ProcessClass.java:127)
                	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
                	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
                	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
                Caused by: jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r16v6 ??
                	at jadx.core.dex.instructions.args.SSAVar.getCodeVar(SSAVar.java:236)
                */
            /*
                Method dump skipped, instruction units count: 1040
                To view this dump change 'Code comments level' option to 'DEBUG'
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.media3.exoplayer.ExoPlayerImpl.<init>(androidx.media3.exoplayer.ExoPlayer$Builder, androidx.media3.common.Player):void");
        }

        public boolean isSleepingForOffload() {
            verifyApplicationThread();
            return this.playbackInfo.sleepingForOffload;
        }

        public Looper getPlaybackLooper() {
            return this.internalPlayer.getPlaybackLooper();
        }

        @Override // androidx.media3.common.Player
        public Looper getApplicationLooper() {
            return this.applicationLooper;
        }

        public Clock getClock() {
            return this.clock;
        }

        public void addAudioOffloadListener(ExoPlayer.AudioOffloadListener audioOffloadListener) {
            this.audioOffloadListeners.add(audioOffloadListener);
        }

        @Override // androidx.media3.common.Player
        public Player.Commands getAvailableCommands() {
            verifyApplicationThread();
            return this.availableCommands;
        }

        @Override // androidx.media3.common.Player
        public int getPlaybackState() {
            verifyApplicationThread();
            return this.playbackInfo.playbackState;
        }

        @Override // androidx.media3.common.Player
        public int getPlaybackSuppressionReason() {
            verifyApplicationThread();
            return this.playbackInfo.playbackSuppressionReason;
        }

        @Override // androidx.media3.common.Player
        public ExoPlaybackException getPlayerError() {
            verifyApplicationThread();
            return this.playbackInfo.playbackError;
        }

        @Override // androidx.media3.common.Player
        public void prepare() {
            verifyApplicationThread();
            PlaybackInfo playbackInfo = this.playbackInfo;
            if (playbackInfo.playbackState != 1) {
                return;
            }
            PlaybackInfo playbackInfoCopyWithPlaybackError = playbackInfo.copyWithPlaybackError(null);
            PlaybackInfo playbackInfoMaskPlaybackState = maskPlaybackState(playbackInfoCopyWithPlaybackError, playbackInfoCopyWithPlaybackError.timeline.isEmpty() ? 4 : 2);
            this.pendingOperationAcks++;
            this.internalPlayer.prepare();
            updatePlaybackInfo(playbackInfoMaskPlaybackState, 1, false, 5, -9223372036854775807L, -1, false);
        }

        @Override // androidx.media3.common.Player
        public void setMediaItems(List list, int i, long j) {
            verifyApplicationThread();
            setMediaSources(createMediaSources(list), i, j);
        }

        @Override // androidx.media3.exoplayer.ExoPlayer
        public void setMediaSource(MediaSource mediaSource, long j) {
            verifyApplicationThread();
            setMediaSources(Collections.singletonList(mediaSource), 0, j);
        }

        public void setMediaSources(List list, int i, long j) {
            verifyApplicationThread();
            setMediaSourcesInternal(list, i, j, false);
        }

        @Override // androidx.media3.common.Player
        public void setPlayWhenReady(boolean z) {
            verifyApplicationThread();
            updatePlayWhenReady(z, 1);
        }

        @Override // androidx.media3.common.Player
        public boolean getPlayWhenReady() {
            verifyApplicationThread();
            return this.playbackInfo.playWhenReady;
        }

        @Override // androidx.media3.common.Player
        public int getRepeatMode() {
            verifyApplicationThread();
            return this.repeatMode;
        }

        @Override // androidx.media3.common.Player
        public boolean getShuffleModeEnabled() {
            verifyApplicationThread();
            return this.shuffleModeEnabled;
        }

        @Override // androidx.media3.common.Player
        public boolean isLoading() {
            verifyApplicationThread();
            return this.playbackInfo.isLoading;
        }

        @Override // androidx.media3.common.BasePlayer
        protected void seekTo(int i, long j, int i2, boolean z) {
            verifyApplicationThread();
            if (i == -1) {
                return;
            }
            Preconditions.checkArgument(i >= 0);
            Timeline timeline = this.playbackInfo.timeline;
            if (timeline.isEmpty() || i < timeline.getWindowCount()) {
                this.analyticsCollector.notifySeekStarted();
                this.pendingOperationAcks++;
                if (isPlayingAd()) {
                    Log.w("ExoPlayerImpl", "seekTo ignored because an ad is playing");
                    ExoPlayerImplInternal.PlaybackInfoUpdate playbackInfoUpdate = new ExoPlayerImplInternal.PlaybackInfoUpdate(this.playbackInfo);
                    playbackInfoUpdate.incrementPendingOperationAcks(1);
                    this.playbackInfoUpdateListener.onPlaybackInfoUpdate(playbackInfoUpdate);
                    return;
                }
                PlaybackInfo playbackInfoMaskPlaybackState = this.playbackInfo;
                int i3 = playbackInfoMaskPlaybackState.playbackState;
                if (i3 == 3 || (i3 == 4 && !timeline.isEmpty())) {
                    playbackInfoMaskPlaybackState = maskPlaybackState(this.playbackInfo, 2);
                }
                int currentMediaItemIndex = getCurrentMediaItemIndex();
                PlaybackInfo playbackInfoMaskTimelineAndPosition = maskTimelineAndPosition(playbackInfoMaskPlaybackState, timeline, maskWindowPositionMsOrGetPeriodPositionUs(timeline, i, j));
                this.internalPlayer.seekTo(timeline, i, Util.msToUs(j));
                updatePlaybackInfo(playbackInfoMaskTimelineAndPosition, 0, true, 1, getCurrentPositionUsInternal(playbackInfoMaskTimelineAndPosition), currentMediaItemIndex, z);
            }
        }

        @Override // androidx.media3.common.Player
        public void setPlaybackParameters(PlaybackParameters playbackParameters) {
            verifyApplicationThread();
            if (playbackParameters == null) {
                playbackParameters = PlaybackParameters.DEFAULT;
            }
            if (this.playbackInfo.playbackParameters.equals(playbackParameters)) {
                return;
            }
            PlaybackInfo playbackInfoCopyWithPlaybackParameters = this.playbackInfo.copyWithPlaybackParameters(playbackParameters);
            this.pendingOperationAcks++;
            this.internalPlayer.setPlaybackParameters(playbackParameters);
            updatePlaybackInfo(playbackInfoCopyWithPlaybackParameters, 0, false, 5, -9223372036854775807L, -1, false);
        }

        @Override // androidx.media3.common.Player
        public PlaybackParameters getPlaybackParameters() {
            verifyApplicationThread();
            return this.playbackInfo.playbackParameters;
        }

        @Override // androidx.media3.exoplayer.ExoPlayer
        public void setSeekParameters(SeekParameters seekParameters) {
            verifyApplicationThread();
            if (seekParameters == null) {
                seekParameters = SeekParameters.DEFAULT;
            }
            if (this.seekParameters.equals(seekParameters)) {
                return;
            }
            this.seekParameters = seekParameters;
            this.internalPlayer.setSeekParameters(seekParameters);
        }

        @Override // androidx.media3.exoplayer.ExoPlayer
        public void release() {
            Log.i("ExoPlayerImpl", "Release " + Integer.toHexString(System.identityHashCode(this)) + " [AndroidXMedia3/1.9.0] [" + Util.DEVICE_DEBUG_INFO + "] [" + MediaLibraryInfo.registeredModules() + "]");
            verifyApplicationThread();
            this.audioBecomingNoisyManager.setEnabled(false);
            StreamVolumeManager streamVolumeManager = this.streamVolumeManager;
            if (streamVolumeManager != null) {
                streamVolumeManager.release();
            }
            this.wakeLockManager.setStayAwake(false);
            this.wifiLockManager.setStayAwake(false);
            SuitableOutputChecker suitableOutputChecker = this.suitableOutputChecker;
            if (suitableOutputChecker != null) {
                suitableOutputChecker.disable();
            }
            VirtualDeviceIdChangeListener virtualDeviceIdChangeListener = this.virtualDeviceIdChangeListener;
            if (virtualDeviceIdChangeListener != null && Build.VERSION.SDK_INT >= 34) {
                virtualDeviceIdChangeListener.release();
            }
            this.stuckPlayerDetector.release();
            if (!this.internalPlayer.release()) {
                this.listeners.sendEvent(10, new ListenerSet.Event() { // from class: androidx.media3.exoplayer.ExoPlayerImpl$$ExternalSyntheticLambda15
                    @Override // androidx.media3.common.util.ListenerSet.Event
                    public final void invoke(Object obj) {
                        ((Player.Listener) obj).onPlayerError(ExoPlaybackException.createForUnexpected(new ExoTimeoutException(1), 1003));
                    }
                });
            }
            this.listeners.release();
            this.playbackInfoUpdateHandler.removeCallbacksAndMessages(null);
            this.bandwidthMeter.removeEventListener(this.analyticsCollector);
            PlaybackInfo playbackInfo = this.playbackInfo;
            if (playbackInfo.sleepingForOffload) {
                this.playbackInfo = playbackInfo.copyWithEstimatedPosition();
            }
            PlaybackInfo playbackInfoMaskPlaybackState = maskPlaybackState(this.playbackInfo, 1);
            this.playbackInfo = playbackInfoMaskPlaybackState;
            PlaybackInfo playbackInfoCopyWithLoadingMediaPeriodId = playbackInfoMaskPlaybackState.copyWithLoadingMediaPeriodId(playbackInfoMaskPlaybackState.periodId);
            this.playbackInfo = playbackInfoCopyWithLoadingMediaPeriodId;
            playbackInfoCopyWithLoadingMediaPeriodId.bufferedPositionUs = playbackInfoCopyWithLoadingMediaPeriodId.positionUs;
            this.playbackInfo.totalBufferedDurationUs = 0L;
            this.analyticsCollector.release();
            removeSurfaceCallbacks();
            Surface surface = this.ownedSurface;
            if (surface != null) {
                surface.release();
                this.ownedSurface = null;
            }
            if (this.isPriorityTaskManagerRegistered) {
                MimeTypes$$ExternalSyntheticThrowCCEIfNotNull0.m(Preconditions.checkNotNull(null));
                throw null;
            }
            this.currentCueGroup = CueGroup.EMPTY_TIME_ZERO;
            this.playerReleased = true;
        }

        @Override // androidx.media3.common.Player
        public int getCurrentPeriodIndex() {
            verifyApplicationThread();
            if (this.playbackInfo.timeline.isEmpty()) {
                int i = this.maskingWindowIndex;
                if (i == -1) {
                    return 0;
                }
                return i;
            }
            PlaybackInfo playbackInfo = this.playbackInfo;
            return playbackInfo.timeline.getIndexOfPeriod(playbackInfo.periodId.periodUid);
        }

        @Override // androidx.media3.common.Player
        public int getCurrentMediaItemIndex() {
            verifyApplicationThread();
            int currentWindowIndexInternal = getCurrentWindowIndexInternal(this.playbackInfo);
            if (currentWindowIndexInternal == -1) {
                return 0;
            }
            return currentWindowIndexInternal;
        }

        @Override // androidx.media3.common.Player
        public long getDuration() {
            verifyApplicationThread();
            if (isPlayingAd()) {
                PlaybackInfo playbackInfo = this.playbackInfo;
                MediaSource.MediaPeriodId mediaPeriodId = playbackInfo.periodId;
                playbackInfo.timeline.getPeriodByUid(mediaPeriodId.periodUid, this.period);
                return Util.usToMs(this.period.getAdDurationUs(mediaPeriodId.adGroupIndex, mediaPeriodId.adIndexInAdGroup));
            }
            return getContentDuration();
        }

        @Override // androidx.media3.common.Player
        public long getCurrentPosition() {
            verifyApplicationThread();
            return Util.usToMs(getCurrentPositionUsInternal(this.playbackInfo));
        }

        @Override // androidx.media3.common.Player
        public long getBufferedPosition() {
            verifyApplicationThread();
            if (isPlayingAd()) {
                PlaybackInfo playbackInfo = this.playbackInfo;
                if (playbackInfo.loadingMediaPeriodId.equals(playbackInfo.periodId)) {
                    return Util.usToMs(this.playbackInfo.bufferedPositionUs);
                }
                return getDuration();
            }
            return getContentBufferedPosition();
        }

        @Override // androidx.media3.common.Player
        public long getTotalBufferedDuration() {
            verifyApplicationThread();
            return Util.usToMs(this.playbackInfo.totalBufferedDurationUs);
        }

        @Override // androidx.media3.common.Player
        public boolean isPlayingAd() {
            verifyApplicationThread();
            return this.playbackInfo.periodId.isAd();
        }

        @Override // androidx.media3.common.Player
        public int getCurrentAdGroupIndex() {
            verifyApplicationThread();
            if (isPlayingAd()) {
                return this.playbackInfo.periodId.adGroupIndex;
            }
            return -1;
        }

        @Override // androidx.media3.common.Player
        public int getCurrentAdIndexInAdGroup() {
            verifyApplicationThread();
            if (isPlayingAd()) {
                return this.playbackInfo.periodId.adIndexInAdGroup;
            }
            return -1;
        }

        @Override // androidx.media3.common.Player
        public long getContentPosition() {
            verifyApplicationThread();
            return getContentPositionInternal(this.playbackInfo);
        }

        public long getContentBufferedPosition() {
            verifyApplicationThread();
            if (this.playbackInfo.timeline.isEmpty()) {
                return this.maskingWindowPositionMs;
            }
            PlaybackInfo playbackInfo = this.playbackInfo;
            if (playbackInfo.loadingMediaPeriodId.windowSequenceNumber != playbackInfo.periodId.windowSequenceNumber) {
                return playbackInfo.timeline.getWindow(getCurrentMediaItemIndex(), this.window).getDurationMs();
            }
            long j = playbackInfo.bufferedPositionUs;
            if (this.playbackInfo.loadingMediaPeriodId.isAd()) {
                PlaybackInfo playbackInfo2 = this.playbackInfo;
                Timeline.Period periodByUid = playbackInfo2.timeline.getPeriodByUid(playbackInfo2.loadingMediaPeriodId.periodUid, this.period);
                long adGroupTimeUs = periodByUid.getAdGroupTimeUs(this.playbackInfo.loadingMediaPeriodId.adGroupIndex);
                j = adGroupTimeUs == Long.MIN_VALUE ? periodByUid.durationUs : adGroupTimeUs;
            }
            PlaybackInfo playbackInfo3 = this.playbackInfo;
            return Util.usToMs(periodPositionUsToWindowPositionUs(playbackInfo3.timeline, playbackInfo3.loadingMediaPeriodId, j));
        }

        @Override // androidx.media3.common.Player
        public Tracks getCurrentTracks() {
            verifyApplicationThread();
            return this.playbackInfo.trackSelectorResult.tracks;
        }

        @Override // androidx.media3.common.Player
        public TrackSelectionParameters getTrackSelectionParameters() {
            verifyApplicationThread();
            TrackSelectionParameters parameters = this.trackSelector.getParameters();
            return this.scrubbingModeEnabled ? parameters.buildUpon().setDisabledTrackTypes(this.disabledTrackTypesWithoutScrubbingMode).build() : parameters;
        }

        @Override // androidx.media3.common.Player
        public void setTrackSelectionParameters(final TrackSelectionParameters trackSelectionParameters) {
            TrackSelectionParameters trackSelectionParametersAddDisabledTrackTypes;
            verifyApplicationThread();
            if (this.trackSelector.isSetParametersSupported()) {
                TrackSelectionParameters trackSelectionParameters2 = getTrackSelectionParameters();
                if (this.scrubbingModeEnabled) {
                    this.disabledTrackTypesWithoutScrubbingMode = trackSelectionParameters.disabledTrackTypes;
                    trackSelectionParametersAddDisabledTrackTypes = addDisabledTrackTypes(trackSelectionParameters, this.scrubbingModeParameters.disabledTrackTypes);
                } else {
                    trackSelectionParametersAddDisabledTrackTypes = trackSelectionParameters;
                }
                if (!trackSelectionParametersAddDisabledTrackTypes.equals(this.trackSelector.getParameters())) {
                    this.trackSelector.setParameters(trackSelectionParametersAddDisabledTrackTypes);
                }
                if (trackSelectionParameters2.equals(trackSelectionParameters)) {
                    return;
                }
                this.listeners.sendEvent(19, new ListenerSet.Event() { // from class: androidx.media3.exoplayer.ExoPlayerImpl$$ExternalSyntheticLambda21
                    @Override // androidx.media3.common.util.ListenerSet.Event
                    public final void invoke(Object obj) {
                        ((Player.Listener) obj).onTrackSelectionParametersChanged(trackSelectionParameters);
                    }
                });
            }
        }

        @Override // androidx.media3.common.Player
        public Timeline getCurrentTimeline() {
            verifyApplicationThread();
            return this.playbackInfo.timeline;
        }

        public void clearVideoSurface() {
            verifyApplicationThread();
            removeSurfaceCallbacks();
            setVideoOutputInternal(null);
            maybeNotifySurfaceSizeChanged(0, 0);
        }

        public void setVideoSurfaceHolder(SurfaceHolder surfaceHolder) {
            verifyApplicationThread();
            if (surfaceHolder == null) {
                clearVideoSurface();
                return;
            }
            removeSurfaceCallbacks();
            this.surfaceHolderSurfaceIsVideoOutput = true;
            this.surfaceHolder = surfaceHolder;
            surfaceHolder.addCallback(this.componentListener);
            Surface surface = surfaceHolder.getSurface();
            if (surface != null && surface.isValid()) {
                setVideoOutputInternal(surface);
                Rect surfaceFrame = surfaceHolder.getSurfaceFrame();
                maybeNotifySurfaceSizeChanged(surfaceFrame.width(), surfaceFrame.height());
            } else {
                setVideoOutputInternal(null);
                maybeNotifySurfaceSizeChanged(0, 0);
            }
        }

        @Override // androidx.media3.common.Player
        public void setVideoSurfaceView(SurfaceView surfaceView) {
            verifyApplicationThread();
            setVideoSurfaceHolder(surfaceView == null ? null : surfaceView.getHolder());
        }

        @Override // androidx.media3.exoplayer.ExoPlayer
        public void addAnalyticsListener(AnalyticsListener analyticsListener) {
            this.analyticsCollector.addListener((AnalyticsListener) Preconditions.checkNotNull(analyticsListener));
        }

        @Override // androidx.media3.exoplayer.ExoPlayer
        public Format getVideoFormat() {
            verifyApplicationThread();
            return this.videoFormat;
        }

        @Override // androidx.media3.common.Player
        public void addListener(Player.Listener listener) {
            this.listeners.add((Player.Listener) Preconditions.checkNotNull(listener));
        }

        @Override // androidx.media3.common.Player
        public void removeListener(Player.Listener listener) {
            verifyApplicationThread();
            this.listeners.remove((Player.Listener) Preconditions.checkNotNull(listener));
        }

        private void stopInternal(ExoPlaybackException exoPlaybackException) {
            PlaybackInfo playbackInfo = this.playbackInfo;
            PlaybackInfo playbackInfoCopyWithLoadingMediaPeriodId = playbackInfo.copyWithLoadingMediaPeriodId(playbackInfo.periodId);
            playbackInfoCopyWithLoadingMediaPeriodId.bufferedPositionUs = playbackInfoCopyWithLoadingMediaPeriodId.positionUs;
            playbackInfoCopyWithLoadingMediaPeriodId.totalBufferedDurationUs = 0L;
            PlaybackInfo playbackInfoMaskPlaybackState = maskPlaybackState(playbackInfoCopyWithLoadingMediaPeriodId, 1);
            if (exoPlaybackException != null) {
                playbackInfoMaskPlaybackState = playbackInfoMaskPlaybackState.copyWithPlaybackError(exoPlaybackException);
            }
            this.pendingOperationAcks++;
            this.internalPlayer.stop();
            updatePlaybackInfo(playbackInfoMaskPlaybackState, 0, false, 5, -9223372036854775807L, -1, false);
        }

        private int getCurrentWindowIndexInternal(PlaybackInfo playbackInfo) {
            if (playbackInfo.timeline.isEmpty()) {
                return this.maskingWindowIndex;
            }
            return playbackInfo.timeline.getPeriodByUid(playbackInfo.periodId.periodUid, this.period).windowIndex;
        }

        private long getContentPositionInternal(PlaybackInfo playbackInfo) {
            if (playbackInfo.periodId.isAd()) {
                playbackInfo.timeline.getPeriodByUid(playbackInfo.periodId.periodUid, this.period);
                if (playbackInfo.requestedContentPositionUs == -9223372036854775807L) {
                    return playbackInfo.timeline.getWindow(getCurrentWindowIndexInternal(playbackInfo), this.window).getDefaultPositionMs();
                }
                return this.period.getPositionInWindowMs() + Util.usToMs(playbackInfo.requestedContentPositionUs);
            }
            return Util.usToMs(getCurrentPositionUsInternal(playbackInfo));
        }

        private long getCurrentPositionUsInternal(PlaybackInfo playbackInfo) {
            long estimatedPositionUs;
            if (playbackInfo.timeline.isEmpty()) {
                return Util.msToUs(this.maskingWindowPositionMs);
            }
            if (playbackInfo.sleepingForOffload) {
                estimatedPositionUs = playbackInfo.getEstimatedPositionUs();
            } else {
                estimatedPositionUs = playbackInfo.positionUs;
            }
            return playbackInfo.periodId.isAd() ? estimatedPositionUs : periodPositionUsToWindowPositionUs(playbackInfo.timeline, playbackInfo.periodId, estimatedPositionUs);
        }

        private List createMediaSources(List list) {
            ArrayList arrayList = new ArrayList();
            for (int i = 0; i < list.size(); i++) {
                arrayList.add(this.mediaSourceFactory.createMediaSource((MediaItem) list.get(i)));
            }
            return arrayList;
        }

        private void handlePlaybackInfo(ExoPlayerImplInternal.PlaybackInfoUpdate playbackInfoUpdate) {
            int i;
            long j;
            boolean z;
            long jPeriodPositionUsToWindowPositionUs;
            int i2 = this.pendingOperationAcks - playbackInfoUpdate.operationAcks;
            this.pendingOperationAcks = i2;
            boolean z2 = true;
            if (playbackInfoUpdate.positionDiscontinuity) {
                this.pendingDiscontinuityReason = playbackInfoUpdate.discontinuityReason;
                this.pendingDiscontinuity = true;
            }
            if (i2 == 0) {
                Timeline timeline = playbackInfoUpdate.playbackInfo.timeline;
                int currentMediaItemIndex = -1;
                if (!this.playbackInfo.timeline.isEmpty() && timeline.isEmpty()) {
                    this.maskingWindowIndex = -1;
                    this.maskingWindowPositionMs = 0L;
                }
                if (!timeline.isEmpty()) {
                    List childTimelines = ((PlaylistTimeline) timeline).getChildTimelines();
                    Preconditions.checkState(childTimelines.size() == this.mediaSourceHolderSnapshots.size());
                    for (int i3 = 0; i3 < childTimelines.size(); i3++) {
                        ((MediaSourceHolderSnapshot) this.mediaSourceHolderSnapshots.get(i3)).updateTimeline((Timeline) childTimelines.get(i3));
                    }
                }
                long j2 = -9223372036854775807L;
                if (this.pendingDiscontinuity) {
                    boolean z3 = playbackInfoUpdate.playbackInfo.timeline.isEmpty() && this.playbackInfo.timeline.isEmpty();
                    boolean zEquals = playbackInfoUpdate.playbackInfo.periodId.equals(this.playbackInfo.periodId);
                    boolean z4 = playbackInfoUpdate.playbackInfo.discontinuityStartPositionUs == this.playbackInfo.positionUs;
                    if (z3 || (zEquals && z4)) {
                        z2 = false;
                    }
                    if (z2) {
                        currentMediaItemIndex = getCurrentMediaItemIndex();
                        if (timeline.isEmpty() || playbackInfoUpdate.playbackInfo.periodId.isAd()) {
                            jPeriodPositionUsToWindowPositionUs = playbackInfoUpdate.playbackInfo.discontinuityStartPositionUs;
                        } else {
                            PlaybackInfo playbackInfo = playbackInfoUpdate.playbackInfo;
                            jPeriodPositionUsToWindowPositionUs = periodPositionUsToWindowPositionUs(timeline, playbackInfo.periodId, playbackInfo.discontinuityStartPositionUs);
                        }
                        j2 = jPeriodPositionUsToWindowPositionUs;
                    }
                    z = z2;
                    long j3 = j2;
                    i = currentMediaItemIndex;
                    j = j3;
                } else {
                    i = -1;
                    j = -9223372036854775807L;
                    z = false;
                }
                this.pendingDiscontinuity = false;
                updatePlaybackInfo(playbackInfoUpdate.playbackInfo, 1, z, this.pendingDiscontinuityReason, j, i, false);
            }
        }

        private void updatePlaybackInfo(final PlaybackInfo playbackInfo, final int i, boolean z, final int i2, long j, int i3, boolean z2) {
            PlaybackInfo playbackInfo2 = this.playbackInfo;
            this.playbackInfo = playbackInfo;
            boolean zEquals = playbackInfo2.timeline.equals(playbackInfo.timeline);
            Pair pairEvaluateMediaItemTransitionReason = evaluateMediaItemTransitionReason(playbackInfo, playbackInfo2, z, i2, !zEquals, z2);
            boolean zBooleanValue = ((Boolean) pairEvaluateMediaItemTransitionReason.first).booleanValue();
            final int iIntValue = ((Integer) pairEvaluateMediaItemTransitionReason.second).intValue();
            final MediaItem mediaItem = null;
            if (zBooleanValue) {
                if (!playbackInfo.timeline.isEmpty()) {
                    mediaItem = playbackInfo.timeline.getWindow(playbackInfo.timeline.getPeriodByUid(playbackInfo.periodId.periodUid, this.period).windowIndex, this.window).mediaItem;
                }
                this.staticAndDynamicMediaMetadata = MediaMetadata.EMPTY;
            }
            if (zBooleanValue || !playbackInfo2.staticMetadata.equals(playbackInfo.staticMetadata)) {
                this.staticAndDynamicMediaMetadata = this.staticAndDynamicMediaMetadata.buildUpon().populateFromMetadata(playbackInfo.staticMetadata).build();
            }
            MediaMetadata mediaMetadataBuildUpdatedMediaMetadata = buildUpdatedMediaMetadata();
            boolean zEquals2 = mediaMetadataBuildUpdatedMediaMetadata.equals(this.mediaMetadata);
            this.mediaMetadata = mediaMetadataBuildUpdatedMediaMetadata;
            boolean z3 = playbackInfo2.playWhenReady != playbackInfo.playWhenReady;
            boolean z4 = playbackInfo2.playbackState != playbackInfo.playbackState;
            if (z4 || z3) {
                updateWakeAndWifiLock();
            }
            boolean z5 = playbackInfo2.isLoading;
            boolean z6 = playbackInfo.isLoading;
            boolean z7 = z5 != z6;
            if (z7) {
                updatePriorityTaskManagerForIsLoadingChange(z6);
            }
            if (!zEquals) {
                this.listeners.queueEvent(0, new ListenerSet.Event() { // from class: androidx.media3.exoplayer.ExoPlayerImpl$$ExternalSyntheticLambda0
                    @Override // androidx.media3.common.util.ListenerSet.Event
                    public final void invoke(Object obj) {
                        Player.Listener listener = (Player.Listener) obj;
                        listener.onTimelineChanged(playbackInfo.timeline, i);
                    }
                });
            }
            if (z) {
                final Player.PositionInfo previousPositionInfo = getPreviousPositionInfo(i2, playbackInfo2, i3);
                final Player.PositionInfo positionInfo = getPositionInfo(j);
                this.listeners.queueEvent(11, new ListenerSet.Event() { // from class: androidx.media3.exoplayer.ExoPlayerImpl$$ExternalSyntheticLambda5
                    @Override // androidx.media3.common.util.ListenerSet.Event
                    public final void invoke(Object obj) {
                        ExoPlayerImpl.$r8$lambda$8Be81IYn7p5UDkd1e1e94_k_Da8(i2, previousPositionInfo, positionInfo, (Player.Listener) obj);
                    }
                });
            }
            if (zBooleanValue) {
                this.listeners.queueEvent(1, new ListenerSet.Event() { // from class: androidx.media3.exoplayer.ExoPlayerImpl$$ExternalSyntheticLambda6
                    @Override // androidx.media3.common.util.ListenerSet.Event
                    public final void invoke(Object obj) {
                        ((Player.Listener) obj).onMediaItemTransition(mediaItem, iIntValue);
                    }
                });
            }
            if (playbackInfo2.playbackError != playbackInfo.playbackError) {
                this.listeners.queueEvent(10, new ListenerSet.Event() { // from class: androidx.media3.exoplayer.ExoPlayerImpl$$ExternalSyntheticLambda7
                    @Override // androidx.media3.common.util.ListenerSet.Event
                    public final void invoke(Object obj) {
                        ((Player.Listener) obj).onPlayerErrorChanged(playbackInfo.playbackError);
                    }
                });
                if (playbackInfo.playbackError != null) {
                    this.listeners.queueEvent(10, new ListenerSet.Event() { // from class: androidx.media3.exoplayer.ExoPlayerImpl$$ExternalSyntheticLambda8
                        @Override // androidx.media3.common.util.ListenerSet.Event
                        public final void invoke(Object obj) {
                            ((Player.Listener) obj).onPlayerError(playbackInfo.playbackError);
                        }
                    });
                }
            }
            TrackSelectorResult trackSelectorResult = playbackInfo2.trackSelectorResult;
            TrackSelectorResult trackSelectorResult2 = playbackInfo.trackSelectorResult;
            if (trackSelectorResult != trackSelectorResult2) {
                this.trackSelector.onSelectionActivated(trackSelectorResult2.info);
                this.listeners.queueEvent(2, new ListenerSet.Event() { // from class: androidx.media3.exoplayer.ExoPlayerImpl$$ExternalSyntheticLambda9
                    @Override // androidx.media3.common.util.ListenerSet.Event
                    public final void invoke(Object obj) {
                        ((Player.Listener) obj).onTracksChanged(playbackInfo.trackSelectorResult.tracks);
                    }
                });
            }
            if (!zEquals2) {
                final MediaMetadata mediaMetadata = this.mediaMetadata;
                this.listeners.queueEvent(14, new ListenerSet.Event() { // from class: androidx.media3.exoplayer.ExoPlayerImpl$$ExternalSyntheticLambda10
                    @Override // androidx.media3.common.util.ListenerSet.Event
                    public final void invoke(Object obj) {
                        ((Player.Listener) obj).onMediaMetadataChanged(mediaMetadata);
                    }
                });
            }
            if (z7) {
                this.listeners.queueEvent(3, new ListenerSet.Event() { // from class: androidx.media3.exoplayer.ExoPlayerImpl$$ExternalSyntheticLambda11
                    @Override // androidx.media3.common.util.ListenerSet.Event
                    public final void invoke(Object obj) {
                        ExoPlayerImpl.$r8$lambda$kYzGcMcungTnaITqB_kFytLJzb4(playbackInfo, (Player.Listener) obj);
                    }
                });
            }
            if (z4 || z3) {
                this.listeners.queueEvent(-1, new ListenerSet.Event() { // from class: androidx.media3.exoplayer.ExoPlayerImpl$$ExternalSyntheticLambda12
                    @Override // androidx.media3.common.util.ListenerSet.Event
                    public final void invoke(Object obj) {
                        PlaybackInfo playbackInfo3 = playbackInfo;
                        ((Player.Listener) obj).onPlayerStateChanged(playbackInfo3.playWhenReady, playbackInfo3.playbackState);
                    }
                });
            }
            if (z4) {
                this.listeners.queueEvent(4, new ListenerSet.Event() { // from class: androidx.media3.exoplayer.ExoPlayerImpl$$ExternalSyntheticLambda13
                    @Override // androidx.media3.common.util.ListenerSet.Event
                    public final void invoke(Object obj) {
                        ((Player.Listener) obj).onPlaybackStateChanged(playbackInfo.playbackState);
                    }
                });
            }
            if (z3 || playbackInfo2.playWhenReadyChangeReason != playbackInfo.playWhenReadyChangeReason) {
                this.listeners.queueEvent(5, new ListenerSet.Event() { // from class: androidx.media3.exoplayer.ExoPlayerImpl$$ExternalSyntheticLambda1
                    @Override // androidx.media3.common.util.ListenerSet.Event
                    public final void invoke(Object obj) {
                        PlaybackInfo playbackInfo3 = playbackInfo;
                        ((Player.Listener) obj).onPlayWhenReadyChanged(playbackInfo3.playWhenReady, playbackInfo3.playWhenReadyChangeReason);
                    }
                });
            }
            if (playbackInfo2.playbackSuppressionReason != playbackInfo.playbackSuppressionReason) {
                this.listeners.queueEvent(6, new ListenerSet.Event() { // from class: androidx.media3.exoplayer.ExoPlayerImpl$$ExternalSyntheticLambda2
                    @Override // androidx.media3.common.util.ListenerSet.Event
                    public final void invoke(Object obj) {
                        ((Player.Listener) obj).onPlaybackSuppressionReasonChanged(playbackInfo.playbackSuppressionReason);
                    }
                });
            }
            if (playbackInfo2.isPlaying() != playbackInfo.isPlaying()) {
                this.listeners.queueEvent(7, new ListenerSet.Event() { // from class: androidx.media3.exoplayer.ExoPlayerImpl$$ExternalSyntheticLambda3
                    @Override // androidx.media3.common.util.ListenerSet.Event
                    public final void invoke(Object obj) {
                        ((Player.Listener) obj).onIsPlayingChanged(playbackInfo.isPlaying());
                    }
                });
            }
            if (!playbackInfo2.playbackParameters.equals(playbackInfo.playbackParameters)) {
                this.listeners.queueEvent(12, new ListenerSet.Event() { // from class: androidx.media3.exoplayer.ExoPlayerImpl$$ExternalSyntheticLambda4
                    @Override // androidx.media3.common.util.ListenerSet.Event
                    public final void invoke(Object obj) {
                        ((Player.Listener) obj).onPlaybackParametersChanged(playbackInfo.playbackParameters);
                    }
                });
            }
            updateAvailableCommands();
            this.listeners.flushEvents();
            if (playbackInfo2.sleepingForOffload != playbackInfo.sleepingForOffload) {
                Iterator it = this.audioOffloadListeners.iterator();
                while (it.hasNext()) {
                    ((ExoPlayer.AudioOffloadListener) it.next()).onSleepingForOffloadChanged(playbackInfo.sleepingForOffload);
                }
            }
        }

        public static /* synthetic */ void $r8$lambda$8Be81IYn7p5UDkd1e1e94_k_Da8(int i, Player.PositionInfo positionInfo, Player.PositionInfo positionInfo2, Player.Listener listener) {
            listener.onPositionDiscontinuity(i);
            listener.onPositionDiscontinuity(positionInfo, positionInfo2, i);
        }

        public static /* synthetic */ void $r8$lambda$kYzGcMcungTnaITqB_kFytLJzb4(PlaybackInfo playbackInfo, Player.Listener listener) {
            listener.onLoadingChanged(playbackInfo.isLoading);
            listener.onIsLoadingChanged(playbackInfo.isLoading);
        }

        private Player.PositionInfo getPreviousPositionInfo(int i, PlaybackInfo playbackInfo, int i2) {
            int i3;
            int i4;
            Object obj;
            MediaItem mediaItem;
            Object obj2;
            long requestedContentPositionUs;
            long requestedContentPositionUs2;
            Timeline.Period period = new Timeline.Period();
            if (playbackInfo.timeline.isEmpty()) {
                i3 = i2;
                i4 = i3;
                obj = null;
                mediaItem = null;
                obj2 = null;
            } else {
                Object obj3 = playbackInfo.periodId.periodUid;
                playbackInfo.timeline.getPeriodByUid(obj3, period);
                int i5 = period.windowIndex;
                int indexOfPeriod = playbackInfo.timeline.getIndexOfPeriod(obj3);
                Object obj4 = playbackInfo.timeline.getWindow(i5, this.window).uid;
                mediaItem = this.window.mediaItem;
                obj2 = obj3;
                i4 = indexOfPeriod;
                obj = obj4;
                i3 = i5;
            }
            if (i == 0) {
                if (playbackInfo.periodId.isAd()) {
                    MediaSource.MediaPeriodId mediaPeriodId = playbackInfo.periodId;
                    requestedContentPositionUs = period.getAdDurationUs(mediaPeriodId.adGroupIndex, mediaPeriodId.adIndexInAdGroup);
                    requestedContentPositionUs2 = getRequestedContentPositionUs(playbackInfo);
                } else {
                    if (playbackInfo.periodId.nextAdGroupIndex != -1) {
                        requestedContentPositionUs = getRequestedContentPositionUs(this.playbackInfo);
                    } else {
                        requestedContentPositionUs = period.positionInWindowUs + period.durationUs;
                    }
                    requestedContentPositionUs2 = requestedContentPositionUs;
                }
            } else if (playbackInfo.periodId.isAd()) {
                requestedContentPositionUs = playbackInfo.positionUs;
                requestedContentPositionUs2 = getRequestedContentPositionUs(playbackInfo);
            } else {
                requestedContentPositionUs = period.positionInWindowUs + playbackInfo.positionUs;
                requestedContentPositionUs2 = requestedContentPositionUs;
            }
            long jUsToMs = Util.usToMs(requestedContentPositionUs);
            long jUsToMs2 = Util.usToMs(requestedContentPositionUs2);
            MediaSource.MediaPeriodId mediaPeriodId2 = playbackInfo.periodId;
            return new Player.PositionInfo(obj, i3, mediaItem, obj2, i4, jUsToMs, jUsToMs2, mediaPeriodId2.adGroupIndex, mediaPeriodId2.adIndexInAdGroup);
        }

        private Player.PositionInfo getPositionInfo(long j) {
            Object obj;
            MediaItem mediaItem;
            Object obj2;
            int currentMediaItemIndex = getCurrentMediaItemIndex();
            int currentPeriodIndex = getCurrentPeriodIndex();
            if (this.playbackInfo.timeline.isEmpty()) {
                obj = null;
                mediaItem = null;
                obj2 = null;
            } else {
                PlaybackInfo playbackInfo = this.playbackInfo;
                Object obj3 = playbackInfo.periodId.periodUid;
                playbackInfo.timeline.getPeriodByUid(obj3, this.period);
                currentPeriodIndex = this.playbackInfo.timeline.getIndexOfPeriod(obj3);
                obj2 = obj3;
                obj = this.playbackInfo.timeline.getWindow(currentMediaItemIndex, this.window).uid;
                mediaItem = this.window.mediaItem;
            }
            int i = currentPeriodIndex;
            long jUsToMs = Util.usToMs(j);
            long jUsToMs2 = this.playbackInfo.periodId.isAd() ? Util.usToMs(getRequestedContentPositionUs(this.playbackInfo)) : jUsToMs;
            MediaSource.MediaPeriodId mediaPeriodId = this.playbackInfo.periodId;
            return new Player.PositionInfo(obj, currentMediaItemIndex, mediaItem, obj2, i, jUsToMs, jUsToMs2, mediaPeriodId.adGroupIndex, mediaPeriodId.adIndexInAdGroup);
        }

        private static long getRequestedContentPositionUs(PlaybackInfo playbackInfo) {
            Timeline.Window window = new Timeline.Window();
            Timeline.Period period = new Timeline.Period();
            playbackInfo.timeline.getPeriodByUid(playbackInfo.periodId.periodUid, period);
            if (playbackInfo.requestedContentPositionUs == -9223372036854775807L) {
                return playbackInfo.timeline.getWindow(period.windowIndex, window).getDefaultPositionUs();
            }
            return period.getPositionInWindowUs() + playbackInfo.requestedContentPositionUs;
        }

        private Pair evaluateMediaItemTransitionReason(PlaybackInfo playbackInfo, PlaybackInfo playbackInfo2, boolean z, int i, boolean z2, boolean z3) {
            Timeline timeline = playbackInfo2.timeline;
            Timeline timeline2 = playbackInfo.timeline;
            if (timeline2.isEmpty() && timeline.isEmpty()) {
                return new Pair(Boolean.FALSE, -1);
            }
            int i2 = 3;
            if (timeline2.isEmpty() != timeline.isEmpty()) {
                return new Pair(Boolean.TRUE, 3);
            }
            if (timeline.getWindow(timeline.getPeriodByUid(playbackInfo2.periodId.periodUid, this.period).windowIndex, this.window).uid.equals(timeline2.getWindow(timeline2.getPeriodByUid(playbackInfo.periodId.periodUid, this.period).windowIndex, this.window).uid)) {
                if (z && i == 0 && playbackInfo2.periodId.windowSequenceNumber < playbackInfo.periodId.windowSequenceNumber) {
                    return new Pair(Boolean.TRUE, 0);
                }
                if (z && i == 1 && z3) {
                    return new Pair(Boolean.TRUE, 2);
                }
                return new Pair(Boolean.FALSE, -1);
            }
            if (z && i == 0) {
                i2 = 1;
            } else if (z && i == 1) {
                i2 = 2;
            } else if (!z2) {
                throw new IllegalStateException();
            }
            return new Pair(Boolean.TRUE, Integer.valueOf(i2));
        }

        private void updateAvailableCommands() {
            Player.Commands commands = this.availableCommands;
            Player.Commands availableCommands = Util.getAvailableCommands(this.wrappingPlayer, this.permanentAvailableCommands);
            this.availableCommands = availableCommands;
            if (availableCommands.equals(commands)) {
                return;
            }
            this.listeners.queueEvent(13, new ListenerSet.Event() { // from class: androidx.media3.exoplayer.ExoPlayerImpl$$ExternalSyntheticLambda23
                @Override // androidx.media3.common.util.ListenerSet.Event
                public final void invoke(Object obj) {
                    ((Player.Listener) obj).onAvailableCommandsChanged(this.f$0.availableCommands);
                }
            });
        }

        private void setMediaSourcesInternal(List list, int i, long j, boolean z) {
            long j2;
            int firstWindowIndex;
            int i2;
            int currentWindowIndexInternal = getCurrentWindowIndexInternal(this.playbackInfo);
            long currentPosition = getCurrentPosition();
            this.pendingOperationAcks++;
            List mediaSourceHolders = setMediaSourceHolders(list, i);
            Timeline timelineCreateMaskingTimeline = createMaskingTimeline();
            if (!timelineCreateMaskingTimeline.isEmpty() && i >= timelineCreateMaskingTimeline.getWindowCount()) {
                throw new IllegalSeekPositionException(timelineCreateMaskingTimeline, i, j);
            }
            if (z) {
                j2 = -9223372036854775807L;
                firstWindowIndex = timelineCreateMaskingTimeline.getFirstWindowIndex(this.shuffleModeEnabled);
            } else if (i == -1) {
                firstWindowIndex = currentWindowIndexInternal;
                j2 = currentPosition;
            } else {
                j2 = j;
                firstWindowIndex = i;
            }
            PlaybackInfo playbackInfoMaskTimelineAndPosition = maskTimelineAndPosition(this.playbackInfo, timelineCreateMaskingTimeline, maskWindowPositionMsOrGetPeriodPositionUs(timelineCreateMaskingTimeline, firstWindowIndex, j2));
            if (playbackInfoMaskTimelineAndPosition.playbackState == 1) {
                i2 = 1;
            } else {
                i2 = 4;
                if (!timelineCreateMaskingTimeline.isEmpty()) {
                    if (firstWindowIndex == -1) {
                        i2 = playbackInfoMaskTimelineAndPosition.playbackState;
                    } else if (firstWindowIndex < timelineCreateMaskingTimeline.getWindowCount()) {
                        i2 = 2;
                    }
                }
            }
            PlaybackInfo playbackInfoMaskPlaybackState = maskPlaybackState(playbackInfoMaskTimelineAndPosition, i2);
            this.internalPlayer.setMediaSources(mediaSourceHolders, firstWindowIndex, Util.msToUs(j2), this.shuffleOrder);
            updatePlaybackInfo(playbackInfoMaskPlaybackState, 0, (this.playbackInfo.periodId.periodUid.equals(playbackInfoMaskPlaybackState.periodId.periodUid) || this.playbackInfo.timeline.isEmpty()) ? false : true, 4, getCurrentPositionUsInternal(playbackInfoMaskPlaybackState), -1, false);
        }

        private List setMediaSourceHolders(List list, int i) {
            this.mediaSourceHolderSnapshots.clear();
            ArrayList arrayList = new ArrayList();
            for (int i2 = 0; i2 < list.size(); i2++) {
                MediaSourceList.MediaSourceHolder mediaSourceHolder = new MediaSourceList.MediaSourceHolder((MediaSource) list.get(i2), this.useLazyPreparation);
                arrayList.add(mediaSourceHolder);
                this.mediaSourceHolderSnapshots.add(i2, new MediaSourceHolderSnapshot(mediaSourceHolder.uid, mediaSourceHolder.mediaSource));
            }
            this.shuffleOrder = this.shuffleOrder.cloneAndSet(arrayList.size(), i);
            return arrayList;
        }

        private Timeline createMaskingTimeline() {
            return new PlaylistTimeline(this.mediaSourceHolderSnapshots, this.shuffleOrder);
        }

        private PlaybackInfo maskTimelineAndPosition(PlaybackInfo playbackInfo, Timeline timeline, Pair pair) {
            long adDurationUs;
            Preconditions.checkArgument(timeline.isEmpty() || pair != null);
            Timeline timeline2 = playbackInfo.timeline;
            long contentPositionInternal = getContentPositionInternal(playbackInfo);
            PlaybackInfo playbackInfoCopyWithTimeline = playbackInfo.copyWithTimeline(timeline);
            if (timeline.isEmpty()) {
                MediaSource.MediaPeriodId dummyPeriodForEmptyTimeline = PlaybackInfo.getDummyPeriodForEmptyTimeline();
                long jMsToUs = Util.msToUs(this.maskingWindowPositionMs);
                PlaybackInfo playbackInfoCopyWithLoadingMediaPeriodId = playbackInfoCopyWithTimeline.copyWithNewPosition(dummyPeriodForEmptyTimeline, jMsToUs, jMsToUs, jMsToUs, 0L, TrackGroupArray.EMPTY, this.emptyTrackSelectorResult, ImmutableList.of()).copyWithLoadingMediaPeriodId(dummyPeriodForEmptyTimeline);
                playbackInfoCopyWithLoadingMediaPeriodId.bufferedPositionUs = playbackInfoCopyWithLoadingMediaPeriodId.positionUs;
                return playbackInfoCopyWithLoadingMediaPeriodId;
            }
            Object obj = playbackInfoCopyWithTimeline.periodId.periodUid;
            boolean zEquals = obj.equals(((Pair) Util.castNonNull(pair)).first);
            MediaSource.MediaPeriodId mediaPeriodId = !zEquals ? new MediaSource.MediaPeriodId(pair.first) : playbackInfoCopyWithTimeline.periodId;
            long jLongValue = ((Long) pair.second).longValue();
            long jMsToUs2 = Util.msToUs(contentPositionInternal);
            if (!timeline2.isEmpty()) {
                jMsToUs2 -= timeline2.getPeriodByUid(obj, this.period).getPositionInWindowUs();
                if (zEquals && jMsToUs2 - jLongValue == 1 && jMsToUs2 == timeline2.getPeriodByUid(obj, this.period).durationUs) {
                    jMsToUs2--;
                }
            }
            if (!zEquals || jLongValue < jMsToUs2) {
                MediaSource.MediaPeriodId mediaPeriodId2 = mediaPeriodId;
                Preconditions.checkState(!mediaPeriodId2.isAd());
                PlaybackInfo playbackInfoCopyWithLoadingMediaPeriodId2 = playbackInfoCopyWithTimeline.copyWithNewPosition(mediaPeriodId2, jLongValue, jLongValue, jLongValue, 0L, !zEquals ? TrackGroupArray.EMPTY : playbackInfoCopyWithTimeline.trackGroups, !zEquals ? this.emptyTrackSelectorResult : playbackInfoCopyWithTimeline.trackSelectorResult, !zEquals ? ImmutableList.of() : playbackInfoCopyWithTimeline.staticMetadata).copyWithLoadingMediaPeriodId(mediaPeriodId2);
                playbackInfoCopyWithLoadingMediaPeriodId2.bufferedPositionUs = jLongValue;
                return playbackInfoCopyWithLoadingMediaPeriodId2;
            }
            if (jLongValue == jMsToUs2) {
                int indexOfPeriod = timeline.getIndexOfPeriod(playbackInfoCopyWithTimeline.loadingMediaPeriodId.periodUid);
                if (indexOfPeriod != -1 && timeline.getPeriod(indexOfPeriod, this.period).windowIndex == timeline.getPeriodByUid(mediaPeriodId.periodUid, this.period).windowIndex) {
                    return playbackInfoCopyWithTimeline;
                }
                timeline.getPeriodByUid(mediaPeriodId.periodUid, this.period);
                if (mediaPeriodId.isAd()) {
                    adDurationUs = this.period.getAdDurationUs(mediaPeriodId.adGroupIndex, mediaPeriodId.adIndexInAdGroup);
                } else {
                    adDurationUs = this.period.durationUs;
                }
                MediaSource.MediaPeriodId mediaPeriodId3 = mediaPeriodId;
                PlaybackInfo playbackInfoCopyWithLoadingMediaPeriodId3 = playbackInfoCopyWithTimeline.copyWithNewPosition(mediaPeriodId3, playbackInfoCopyWithTimeline.positionUs, playbackInfoCopyWithTimeline.positionUs, playbackInfoCopyWithTimeline.discontinuityStartPositionUs, adDurationUs - playbackInfoCopyWithTimeline.positionUs, playbackInfoCopyWithTimeline.trackGroups, playbackInfoCopyWithTimeline.trackSelectorResult, playbackInfoCopyWithTimeline.staticMetadata).copyWithLoadingMediaPeriodId(mediaPeriodId3);
                playbackInfoCopyWithLoadingMediaPeriodId3.bufferedPositionUs = adDurationUs;
                return playbackInfoCopyWithLoadingMediaPeriodId3;
            }
            MediaSource.MediaPeriodId mediaPeriodId4 = mediaPeriodId;
            Preconditions.checkState(!mediaPeriodId4.isAd());
            long jMax = Math.max(0L, playbackInfoCopyWithTimeline.totalBufferedDurationUs - (jLongValue - jMsToUs2));
            long j = playbackInfoCopyWithTimeline.bufferedPositionUs;
            if (playbackInfoCopyWithTimeline.loadingMediaPeriodId.equals(playbackInfoCopyWithTimeline.periodId)) {
                j = jLongValue + jMax;
            }
            PlaybackInfo playbackInfoCopyWithNewPosition = playbackInfoCopyWithTimeline.copyWithNewPosition(mediaPeriodId4, jLongValue, jLongValue, jLongValue, jMax, playbackInfoCopyWithTimeline.trackGroups, playbackInfoCopyWithTimeline.trackSelectorResult, playbackInfoCopyWithTimeline.staticMetadata);
            playbackInfoCopyWithNewPosition.bufferedPositionUs = j;
            return playbackInfoCopyWithNewPosition;
        }

        private static PlaybackInfo maskPlaybackState(PlaybackInfo playbackInfo, int i) {
            PlaybackInfo playbackInfoCopyWithPlaybackState = playbackInfo.copyWithPlaybackState(i);
            return (i == 1 || i == 4) ? playbackInfoCopyWithPlaybackState.copyWithIsLoading(false) : playbackInfoCopyWithPlaybackState;
        }

        private Pair maskWindowPositionMsOrGetPeriodPositionUs(Timeline timeline, int i, long j) {
            if (timeline.isEmpty()) {
                this.maskingWindowIndex = i;
                if (j == -9223372036854775807L) {
                    j = 0;
                }
                this.maskingWindowPositionMs = j;
                return null;
            }
            if (i == -1 || i >= timeline.getWindowCount()) {
                i = timeline.getFirstWindowIndex(this.shuffleModeEnabled);
                j = timeline.getWindow(i, this.window).getDefaultPositionMs();
            }
            return timeline.getPeriodPositionUs(this.window, this.period, i, Util.msToUs(j));
        }

        private long periodPositionUsToWindowPositionUs(Timeline timeline, MediaSource.MediaPeriodId mediaPeriodId, long j) {
            timeline.getPeriodByUid(mediaPeriodId.periodUid, this.period);
            return j + this.period.getPositionInWindowUs();
        }

        private PlayerMessage createMessageInternal(PlayerMessage.Target target) {
            int currentWindowIndexInternal = getCurrentWindowIndexInternal(this.playbackInfo);
            ExoPlayerImplInternal exoPlayerImplInternal = this.internalPlayer;
            Timeline timeline = this.playbackInfo.timeline;
            if (currentWindowIndexInternal == -1) {
                currentWindowIndexInternal = 0;
            }
            return new PlayerMessage(exoPlayerImplInternal, target, timeline, currentWindowIndexInternal, this.clock, exoPlayerImplInternal.getPlaybackLooper());
        }

        private MediaMetadata buildUpdatedMediaMetadata() {
            Timeline currentTimeline = getCurrentTimeline();
            if (currentTimeline.isEmpty()) {
                return this.staticAndDynamicMediaMetadata;
            }
            return this.staticAndDynamicMediaMetadata.buildUpon().populate(currentTimeline.getWindow(getCurrentMediaItemIndex(), this.window).mediaItem.mediaMetadata).build();
        }

        private void removeSurfaceCallbacks() {
            TextureView textureView = this.textureView;
            if (textureView != null) {
                if (textureView.getSurfaceTextureListener() != this.componentListener) {
                    Log.w("ExoPlayerImpl", "SurfaceTextureListener already unset or replaced.");
                } else {
                    this.textureView.setSurfaceTextureListener(null);
                }
                this.textureView = null;
            }
            SurfaceHolder surfaceHolder = this.surfaceHolder;
            if (surfaceHolder != null) {
                surfaceHolder.removeCallback(this.componentListener);
                this.surfaceHolder = null;
            }
        }

        private void setSurfaceTextureInternal(SurfaceTexture surfaceTexture) {
            Surface surface = new Surface(surfaceTexture);
            setVideoOutputInternal(surface);
            this.ownedSurface = surface;
        }

        private void setVideoOutputInternal(Object obj) {
            Object obj2 = this.videoOutput;
            boolean z = (obj2 == null || obj2 == obj) ? false : true;
            boolean videoOutput = this.internalPlayer.setVideoOutput(obj, z ? this.detachSurfaceTimeoutMs : -9223372036854775807L);
            if (z) {
                Object obj3 = this.videoOutput;
                Surface surface = this.ownedSurface;
                if (obj3 == surface) {
                    surface.release();
                    this.ownedSurface = null;
                }
            }
            this.videoOutput = obj;
            if (videoOutput) {
                return;
            }
            stopInternal(ExoPlaybackException.createForUnexpected(new ExoTimeoutException(3), 1003));
        }

        private void maybeNotifySurfaceSizeChanged(final int i, final int i2) {
            if (i == this.surfaceSize.getWidth() && i2 == this.surfaceSize.getHeight()) {
                return;
            }
            this.surfaceSize = new Size(i, i2);
            this.listeners.sendEvent(24, new ListenerSet.Event() { // from class: androidx.media3.exoplayer.ExoPlayerImpl$$ExternalSyntheticLambda14
                @Override // androidx.media3.common.util.ListenerSet.Event
                public final void invoke(Object obj) {
                    ((Player.Listener) obj).onSurfaceSizeChanged(i, i2);
                }
            });
            sendRendererMessage(2, 14, new Size(i, i2));
        }

        private void maybeUpdatePlaybackSuppressionReason() {
            PlaybackInfo playbackInfo = this.playbackInfo;
            updatePlayWhenReady(playbackInfo.playWhenReady, playbackInfo.playWhenReadyChangeReason);
        }

        private void updatePlayWhenReady(boolean z, int i) {
            int iComputePlaybackSuppressionReason = computePlaybackSuppressionReason(z);
            PlaybackInfo playbackInfoCopyWithEstimatedPosition = this.playbackInfo;
            if (playbackInfoCopyWithEstimatedPosition.playWhenReady == z && playbackInfoCopyWithEstimatedPosition.playbackSuppressionReason == iComputePlaybackSuppressionReason && playbackInfoCopyWithEstimatedPosition.playWhenReadyChangeReason == i) {
                return;
            }
            this.pendingOperationAcks++;
            if (playbackInfoCopyWithEstimatedPosition.sleepingForOffload) {
                playbackInfoCopyWithEstimatedPosition = playbackInfoCopyWithEstimatedPosition.copyWithEstimatedPosition();
            }
            PlaybackInfo playbackInfoCopyWithPlayWhenReady = playbackInfoCopyWithEstimatedPosition.copyWithPlayWhenReady(z, i, iComputePlaybackSuppressionReason);
            this.internalPlayer.setPlayWhenReady(z, i, iComputePlaybackSuppressionReason);
            updatePlaybackInfo(playbackInfoCopyWithPlayWhenReady, 0, false, 5, -9223372036854775807L, -1, false);
        }

        private int computePlaybackSuppressionReason(boolean z) {
            if (this.scrubbingModeEnabled) {
                return 4;
            }
            SuitableOutputChecker suitableOutputChecker = this.suitableOutputChecker;
            if (suitableOutputChecker == null || suitableOutputChecker.isSelectedOutputSuitableForPlayback()) {
                return (this.playbackInfo.playbackSuppressionReason != 1 || z) ? 0 : 1;
            }
            return 3;
        }

        private void updateWakeAndWifiLock() {
            int playbackState = getPlaybackState();
            boolean z = false;
            if (playbackState != 1) {
                if (playbackState == 2 || playbackState == 3) {
                    boolean zIsSleepingForOffload = isSleepingForOffload();
                    WakeLockManager wakeLockManager = this.wakeLockManager;
                    if (getPlayWhenReady() && !zIsSleepingForOffload) {
                        z = true;
                    }
                    wakeLockManager.setStayAwake(z);
                    this.wifiLockManager.setStayAwake(getPlayWhenReady());
                    return;
                }
                if (playbackState != 4) {
                    throw new IllegalStateException();
                }
            }
            this.wakeLockManager.setStayAwake(false);
            this.wifiLockManager.setStayAwake(false);
        }

        private void verifyApplicationThread() {
            this.constructorFinished.blockUninterruptible();
            if (Thread.currentThread() != getApplicationLooper().getThread()) {
                String invariant = Util.formatInvariant("Player is accessed on the wrong thread.\nCurrent thread: '%s'\nExpected thread: '%s'\nSee https://developer.android.com/guide/topics/media/issues/player-accessed-on-wrong-thread", Thread.currentThread().getName(), getApplicationLooper().getThread().getName());
                if (this.throwsWhenUsingWrongThread) {
                    throw new IllegalStateException(invariant);
                }
                Log.w("ExoPlayerImpl", invariant, this.hasNotifiedFullWrongThreadWarning ? null : new IllegalStateException());
                this.hasNotifiedFullWrongThreadWarning = true;
            }
        }

        private void sendRendererMessage(int i, Object obj) {
            sendRendererMessage(-1, i, obj);
        }

        private void sendRendererMessage(int i, int i2, Object obj) {
            for (Renderer renderer : this.renderers) {
                if (i == -1 || renderer.getTrackType() == i) {
                    createMessageInternal(renderer).setType(i2).setPayload(obj).send();
                }
            }
            for (Renderer renderer2 : this.secondaryRenderers) {
                if (renderer2 != null && (i == -1 || renderer2.getTrackType() == i)) {
                    createMessageInternal(renderer2).setType(i2).setPayload(obj).send();
                }
            }
        }

        private void onSelectedOutputSuitabilityChanged(boolean z) {
            if (this.playerReleased) {
                return;
            }
            if (z) {
                if (this.playbackInfo.playbackSuppressionReason == 3) {
                    maybeUpdatePlaybackSuppressionReason();
                    return;
                }
                return;
            }
            maybeUpdatePlaybackSuppressionReason();
        }

        private void onAudioSessionIdChanged(int i, final int i2) {
            verifyApplicationThread();
            sendRendererMessage(1, 10, Integer.valueOf(i2));
            sendRendererMessage(2, 10, Integer.valueOf(i2));
            this.listeners.sendEvent(21, new ListenerSet.Event() { // from class: androidx.media3.exoplayer.ExoPlayerImpl$$ExternalSyntheticLambda24
                @Override // androidx.media3.common.util.ListenerSet.Event
                public final void invoke(Object obj) {
                    ((Player.Listener) obj).onAudioSessionIdChanged(i2);
                }
            });
        }

        private static DeviceInfo createDeviceInfo(StreamVolumeManager streamVolumeManager) {
            return new DeviceInfo.Builder(0).setMinVolume(streamVolumeManager != null ? streamVolumeManager.getMinVolume() : 0).setMaxVolume(streamVolumeManager != null ? streamVolumeManager.getMaxVolume() : 0).build();
        }

        private static TrackSelectionParameters addDisabledTrackTypes(TrackSelectionParameters trackSelectionParameters, ImmutableSet immutableSet) {
            TrackSelectionParameters.Builder builderBuildUpon = trackSelectionParameters.buildUpon();
            UnmodifiableIterator it = immutableSet.iterator();
            while (it.hasNext()) {
                builderBuildUpon.setTrackTypeDisabled(((Integer) it.next()).intValue(), true);
            }
            return builderBuildUpon.build();
        }

        private final class CodecParameterListenerManager {
            private CodecParameters lastNotifiedParameters;
            private final Map listeners;
            private final int trackType;

            private CodecParameterListenerManager(int i) {
                this.trackType = i;
                this.listeners = new HashMap();
                this.lastNotifiedParameters = CodecParameters.EMPTY;
            }

            private void onParametersChanged(CodecParameters codecParameters) {
                for (Map.Entry entry : new HashMap(this.listeners).entrySet()) {
                    MimeTypes$$ExternalSyntheticThrowCCEIfNotNull0.m(entry.getKey());
                    List list = (List) entry.getValue();
                    if (!createFilteredCodecParameters(codecParameters, list).equals(createFilteredCodecParameters(this.lastNotifiedParameters, list))) {
                        throw null;
                    }
                }
                this.lastNotifiedParameters = codecParameters;
            }

            private CodecParameters createFilteredCodecParameters(CodecParameters codecParameters, List list) {
                CodecParameters.Builder builderBuildUpon = codecParameters.buildUpon();
                HashSet hashSet = new HashSet(list);
                for (String str : codecParameters.keySet()) {
                    if (!hashSet.contains(str)) {
                        builderBuildUpon.remove(str);
                    }
                }
                return builderBuildUpon.build();
            }
        }

        private static final class MediaSourceHolderSnapshot implements MediaSourceInfoHolder {
            private final MediaSource mediaSource;
            private Timeline timeline;
            private final Object uid;

            public MediaSourceHolderSnapshot(Object obj, MaskingMediaSource maskingMediaSource) {
                this.uid = obj;
                this.mediaSource = maskingMediaSource;
                this.timeline = maskingMediaSource.getTimeline();
            }

            @Override // androidx.media3.exoplayer.MediaSourceInfoHolder
            public Object getUid() {
                return this.uid;
            }

            @Override // androidx.media3.exoplayer.MediaSourceInfoHolder
            public Timeline getTimeline() {
                return this.timeline;
            }

            public void updateTimeline(Timeline timeline) {
                this.timeline = timeline;
            }
        }

        private final class ComponentListener implements VideoRendererEventListener, AudioRendererEventListener, TextOutput, MetadataOutput, SurfaceHolder.Callback, TextureView.SurfaceTextureListener, AudioBecomingNoisyManager.Listener, StreamVolumeManager.Listener, ExoPlayer.AudioOffloadListener, StuckPlayerDetector.Callback {
            @Override // android.view.TextureView.SurfaceTextureListener
            public void onSurfaceTextureUpdated(SurfaceTexture surfaceTexture) {
            }

            private ComponentListener() {
            }

            @Override // androidx.media3.exoplayer.video.VideoRendererEventListener
            public void onVideoEnabled(DecoderCounters decoderCounters) {
                ExoPlayerImpl.this.videoDecoderCounters = decoderCounters;
                ExoPlayerImpl.this.analyticsCollector.onVideoEnabled(decoderCounters);
            }

            @Override // androidx.media3.exoplayer.video.VideoRendererEventListener
            public void onVideoDecoderInitialized(String str, long j, long j2) {
                ExoPlayerImpl.this.analyticsCollector.onVideoDecoderInitialized(str, j, j2);
            }

            @Override // androidx.media3.exoplayer.video.VideoRendererEventListener
            public void onVideoInputFormatChanged(Format format, DecoderReuseEvaluation decoderReuseEvaluation) {
                ExoPlayerImpl.this.videoFormat = format;
                ExoPlayerImpl.this.analyticsCollector.onVideoInputFormatChanged(format, decoderReuseEvaluation);
            }

            @Override // androidx.media3.exoplayer.video.VideoRendererEventListener
            public void onDroppedFrames(int i, long j) {
                ExoPlayerImpl.this.analyticsCollector.onDroppedFrames(i, j);
            }

            @Override // androidx.media3.exoplayer.video.VideoRendererEventListener
            public void onVideoSizeChanged(final VideoSize videoSize) {
                ExoPlayerImpl.this.videoSize = videoSize;
                ExoPlayerImpl.this.listeners.sendEvent(25, new ListenerSet.Event() { // from class: androidx.media3.exoplayer.ExoPlayerImpl$ComponentListener$$ExternalSyntheticLambda7
                    @Override // androidx.media3.common.util.ListenerSet.Event
                    public final void invoke(Object obj) {
                        ((Player.Listener) obj).onVideoSizeChanged(videoSize);
                    }
                });
            }

            @Override // androidx.media3.exoplayer.video.VideoRendererEventListener
            public void onRenderedFirstFrame(Object obj, long j) {
                ExoPlayerImpl.this.analyticsCollector.onRenderedFirstFrame(obj, j);
                if (ExoPlayerImpl.this.videoOutput == obj) {
                    ExoPlayerImpl.this.listeners.sendEvent(26, new ListenerSet.Event() { // from class: androidx.media3.exoplayer.ExoPlayerImpl$ComponentListener$$ExternalSyntheticLambda8
                        @Override // androidx.media3.common.util.ListenerSet.Event
                        public final void invoke(Object obj2) {
                            ((Player.Listener) obj2).onRenderedFirstFrame();
                        }
                    });
                }
            }

            @Override // androidx.media3.exoplayer.video.VideoRendererEventListener
            public void onVideoDecoderReleased(String str) {
                ExoPlayerImpl.this.analyticsCollector.onVideoDecoderReleased(str);
            }

            @Override // androidx.media3.exoplayer.video.VideoRendererEventListener
            public void onVideoDisabled(DecoderCounters decoderCounters) {
                ExoPlayerImpl.this.analyticsCollector.onVideoDisabled(decoderCounters);
                ExoPlayerImpl.this.videoFormat = null;
                ExoPlayerImpl.this.videoDecoderCounters = null;
            }

            @Override // androidx.media3.exoplayer.video.VideoRendererEventListener
            public void onVideoFrameProcessingOffset(long j, int i) {
                ExoPlayerImpl.this.analyticsCollector.onVideoFrameProcessingOffset(j, i);
            }

            @Override // androidx.media3.exoplayer.video.VideoRendererEventListener
            public void onVideoCodecError(Exception exc) {
                ExoPlayerImpl.this.analyticsCollector.onVideoCodecError(exc);
            }

            @Override // androidx.media3.exoplayer.audio.AudioRendererEventListener
            public void onAudioEnabled(DecoderCounters decoderCounters) {
                ExoPlayerImpl.this.audioDecoderCounters = decoderCounters;
                ExoPlayerImpl.this.analyticsCollector.onAudioEnabled(decoderCounters);
            }

            @Override // androidx.media3.exoplayer.audio.AudioRendererEventListener
            public void onAudioDecoderInitialized(String str, long j, long j2) {
                ExoPlayerImpl.this.analyticsCollector.onAudioDecoderInitialized(str, j, j2);
            }

            @Override // androidx.media3.exoplayer.audio.AudioRendererEventListener
            public void onAudioInputFormatChanged(Format format, DecoderReuseEvaluation decoderReuseEvaluation) {
                ExoPlayerImpl.this.audioFormat = format;
                ExoPlayerImpl.this.analyticsCollector.onAudioInputFormatChanged(format, decoderReuseEvaluation);
            }

            @Override // androidx.media3.exoplayer.audio.AudioRendererEventListener
            public void onAudioPositionAdvancing(long j) {
                ExoPlayerImpl.this.analyticsCollector.onAudioPositionAdvancing(j);
            }

            @Override // androidx.media3.exoplayer.audio.AudioRendererEventListener
            public void onAudioUnderrun(int i, long j, long j2) {
                ExoPlayerImpl.this.analyticsCollector.onAudioUnderrun(i, j, j2);
            }

            @Override // androidx.media3.exoplayer.audio.AudioRendererEventListener
            public void onAudioDecoderReleased(String str) {
                ExoPlayerImpl.this.analyticsCollector.onAudioDecoderReleased(str);
            }

            @Override // androidx.media3.exoplayer.audio.AudioRendererEventListener
            public void onAudioDisabled(DecoderCounters decoderCounters) {
                ExoPlayerImpl.this.analyticsCollector.onAudioDisabled(decoderCounters);
                ExoPlayerImpl.this.audioFormat = null;
                ExoPlayerImpl.this.audioDecoderCounters = null;
            }

            @Override // androidx.media3.exoplayer.audio.AudioRendererEventListener
            public void onSkipSilenceEnabledChanged(final boolean z) {
                if (ExoPlayerImpl.this.skipSilenceEnabled == z) {
                    return;
                }
                ExoPlayerImpl.this.skipSilenceEnabled = z;
                ExoPlayerImpl.this.listeners.sendEvent(23, new ListenerSet.Event() { // from class: androidx.media3.exoplayer.ExoPlayerImpl$ComponentListener$$ExternalSyntheticLambda5
                    @Override // androidx.media3.common.util.ListenerSet.Event
                    public final void invoke(Object obj) {
                        ((Player.Listener) obj).onSkipSilenceEnabledChanged(z);
                    }
                });
            }

            @Override // androidx.media3.exoplayer.audio.AudioRendererEventListener
            public void onAudioSinkError(Exception exc) {
                ExoPlayerImpl.this.analyticsCollector.onAudioSinkError(exc);
            }

            @Override // androidx.media3.exoplayer.audio.AudioRendererEventListener
            public void onAudioCodecError(Exception exc) {
                ExoPlayerImpl.this.analyticsCollector.onAudioCodecError(exc);
            }

            @Override // androidx.media3.exoplayer.audio.AudioRendererEventListener
            public void onAudioTrackInitialized(AudioSink.AudioTrackConfig audioTrackConfig) {
                ExoPlayerImpl.this.analyticsCollector.onAudioTrackInitialized(audioTrackConfig);
            }

            @Override // androidx.media3.exoplayer.audio.AudioRendererEventListener
            public void onAudioTrackReleased(AudioSink.AudioTrackConfig audioTrackConfig) {
                ExoPlayerImpl.this.analyticsCollector.onAudioTrackReleased(audioTrackConfig);
            }

            @Override // androidx.media3.exoplayer.audio.AudioRendererEventListener
            public void onAudioSessionIdChanged(final int i) {
                ExoPlayerImpl.this.audioSessionIdState.updateStateAsync(new Function() { // from class: androidx.media3.exoplayer.ExoPlayerImpl$ComponentListener$$ExternalSyntheticLambda1
                    @Override // com.google.common.base.Function
                    public final Object apply(Object obj) {
                        return Integer.valueOf(i);
                    }
                }, new Function() { // from class: androidx.media3.exoplayer.ExoPlayerImpl$ComponentListener$$ExternalSyntheticLambda2
                    @Override // com.google.common.base.Function
                    public final Object apply(Object obj) {
                        return Integer.valueOf(i);
                    }
                });
            }

            @Override // androidx.media3.exoplayer.audio.AudioRendererEventListener
            public void onAudioCodecParametersChanged(CodecParameters codecParameters) {
                ExoPlayerImpl.this.audioListenerManager.onParametersChanged(codecParameters);
            }

            @Override // androidx.media3.exoplayer.video.VideoRendererEventListener
            public void onVideoCodecParametersChanged(CodecParameters codecParameters) {
                ExoPlayerImpl.this.videoListenerManager.onParametersChanged(codecParameters);
            }

            @Override // androidx.media3.exoplayer.text.TextOutput
            public void onCues(final List list) {
                ExoPlayerImpl.this.listeners.sendEvent(27, new ListenerSet.Event() { // from class: androidx.media3.exoplayer.ExoPlayerImpl$ComponentListener$$ExternalSyntheticLambda6
                    @Override // androidx.media3.common.util.ListenerSet.Event
                    public final void invoke(Object obj) {
                        ((Player.Listener) obj).onCues(list);
                    }
                });
            }

            @Override // androidx.media3.exoplayer.text.TextOutput
            public void onCues(final CueGroup cueGroup) {
                ExoPlayerImpl.this.currentCueGroup = cueGroup;
                ExoPlayerImpl.this.listeners.sendEvent(27, new ListenerSet.Event() { // from class: androidx.media3.exoplayer.ExoPlayerImpl$ComponentListener$$ExternalSyntheticLambda0
                    @Override // androidx.media3.common.util.ListenerSet.Event
                    public final void invoke(Object obj) {
                        ((Player.Listener) obj).onCues(cueGroup);
                    }
                });
            }

            @Override // androidx.media3.exoplayer.metadata.MetadataOutput
            public void onMetadata(final Metadata metadata) {
                ExoPlayerImpl exoPlayerImpl = ExoPlayerImpl.this;
                exoPlayerImpl.staticAndDynamicMediaMetadata = exoPlayerImpl.staticAndDynamicMediaMetadata.buildUpon().populateFromMetadata(metadata).build();
                MediaMetadata mediaMetadataBuildUpdatedMediaMetadata = ExoPlayerImpl.this.buildUpdatedMediaMetadata();
                if (!mediaMetadataBuildUpdatedMediaMetadata.equals(ExoPlayerImpl.this.mediaMetadata)) {
                    ExoPlayerImpl.this.mediaMetadata = mediaMetadataBuildUpdatedMediaMetadata;
                    ExoPlayerImpl.this.listeners.queueEvent(14, new ListenerSet.Event() { // from class: androidx.media3.exoplayer.ExoPlayerImpl$ComponentListener$$ExternalSyntheticLambda3
                        @Override // androidx.media3.common.util.ListenerSet.Event
                        public final void invoke(Object obj) {
                            ((Player.Listener) obj).onMediaMetadataChanged(ExoPlayerImpl.this.mediaMetadata);
                        }
                    });
                }
                ExoPlayerImpl.this.listeners.queueEvent(28, new ListenerSet.Event() { // from class: androidx.media3.exoplayer.ExoPlayerImpl$ComponentListener$$ExternalSyntheticLambda4
                    @Override // androidx.media3.common.util.ListenerSet.Event
                    public final void invoke(Object obj) {
                        ((Player.Listener) obj).onMetadata(metadata);
                    }
                });
                ExoPlayerImpl.this.listeners.flushEvents();
            }

            @Override // android.view.SurfaceHolder.Callback
            public void surfaceCreated(SurfaceHolder surfaceHolder) {
                if (ExoPlayerImpl.this.surfaceHolderSurfaceIsVideoOutput) {
                    ExoPlayerImpl.this.setVideoOutputInternal(surfaceHolder.getSurface());
                }
            }

            @Override // android.view.SurfaceHolder.Callback
            public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i2, int i3) {
                ExoPlayerImpl.this.maybeNotifySurfaceSizeChanged(i2, i3);
            }

            @Override // android.view.SurfaceHolder.Callback
            public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
                if (ExoPlayerImpl.this.surfaceHolderSurfaceIsVideoOutput) {
                    ExoPlayerImpl.this.setVideoOutputInternal(null);
                }
                ExoPlayerImpl.this.maybeNotifySurfaceSizeChanged(0, 0);
            }

            @Override // android.view.TextureView.SurfaceTextureListener
            public void onSurfaceTextureAvailable(SurfaceTexture surfaceTexture, int i, int i2) {
                ExoPlayerImpl.this.setSurfaceTextureInternal(surfaceTexture);
                ExoPlayerImpl.this.maybeNotifySurfaceSizeChanged(i, i2);
            }

            @Override // android.view.TextureView.SurfaceTextureListener
            public void onSurfaceTextureSizeChanged(SurfaceTexture surfaceTexture, int i, int i2) {
                ExoPlayerImpl.this.maybeNotifySurfaceSizeChanged(i, i2);
            }

            @Override // android.view.TextureView.SurfaceTextureListener
            public boolean onSurfaceTextureDestroyed(SurfaceTexture surfaceTexture) {
                ExoPlayerImpl.this.setVideoOutputInternal(null);
                ExoPlayerImpl.this.maybeNotifySurfaceSizeChanged(0, 0);
                return true;
            }

            @Override // androidx.media3.common.audio.AudioBecomingNoisyManager.Listener
            public void onAudioBecomingNoisy() {
                ExoPlayerImpl.this.updatePlayWhenReady(false, 3);
            }

            @Override // androidx.media3.exoplayer.StreamVolumeManager.Listener
            public void onStreamTypeChanged(int i) {
                final DeviceInfo deviceInfoCreateDeviceInfo = ExoPlayerImpl.createDeviceInfo(ExoPlayerImpl.this.streamVolumeManager);
                if (deviceInfoCreateDeviceInfo.equals(ExoPlayerImpl.this.deviceInfo)) {
                    return;
                }
                ExoPlayerImpl.this.deviceInfo = deviceInfoCreateDeviceInfo;
                ExoPlayerImpl.this.listeners.sendEvent(29, new ListenerSet.Event() { // from class: androidx.media3.exoplayer.ExoPlayerImpl$ComponentListener$$ExternalSyntheticLambda9
                    @Override // androidx.media3.common.util.ListenerSet.Event
                    public final void invoke(Object obj) {
                        ((Player.Listener) obj).onDeviceInfoChanged(deviceInfoCreateDeviceInfo);
                    }
                });
            }

            @Override // androidx.media3.exoplayer.StreamVolumeManager.Listener
            public void onStreamVolumeChanged(final int i, final boolean z) {
                ExoPlayerImpl.this.listeners.sendEvent(30, new ListenerSet.Event() { // from class: androidx.media3.exoplayer.ExoPlayerImpl$ComponentListener$$ExternalSyntheticLambda10
                    @Override // androidx.media3.common.util.ListenerSet.Event
                    public final void invoke(Object obj) {
                        ((Player.Listener) obj).onDeviceVolumeChanged(i, z);
                    }
                });
            }

            @Override // androidx.media3.exoplayer.ExoPlayer.AudioOffloadListener
            public void onSleepingForOffloadChanged(boolean z) {
                ExoPlayerImpl.this.updateWakeAndWifiLock();
            }

            @Override // androidx.media3.common.util.StuckPlayerDetector.Callback
            public void onStuckPlayerDetected(StuckPlayerException stuckPlayerException) {
                ExoPlayerImpl.this.stopInternal(ExoPlaybackException.createForUnexpected(stuckPlayerException, 1003));
            }
        }

        private static final class FrameMetadataListener implements VideoFrameMetadataListener, CameraMotionListener, PlayerMessage.Target {
            private CameraMotionListener cameraMotionListener;
            private CameraMotionListener internalCameraMotionListener;
            private VideoFrameMetadataListener internalVideoFrameMetadataListener;
            private VideoFrameMetadataListener videoFrameMetadataListener;

            private FrameMetadataListener() {
            }

            @Override // androidx.media3.exoplayer.PlayerMessage.Target
            public void handleMessage(int i, Object obj) {
                if (i == 7) {
                    this.videoFrameMetadataListener = (VideoFrameMetadataListener) obj;
                    return;
                }
                if (i == 8) {
                    this.cameraMotionListener = (CameraMotionListener) obj;
                } else {
                    if (i != 10000) {
                        return;
                    }
                    MimeTypes$$ExternalSyntheticThrowCCEIfNotNull0.m(obj);
                    this.internalVideoFrameMetadataListener = null;
                    this.internalCameraMotionListener = null;
                }
            }

            @Override // androidx.media3.exoplayer.video.VideoFrameMetadataListener
            public void onVideoFrameAboutToBeRendered(long j, long j2, Format format, MediaFormat mediaFormat) {
                long j3;
                long j4;
                Format format2;
                MediaFormat mediaFormat2;
                VideoFrameMetadataListener videoFrameMetadataListener = this.internalVideoFrameMetadataListener;
                if (videoFrameMetadataListener != null) {
                    videoFrameMetadataListener.onVideoFrameAboutToBeRendered(j, j2, format, mediaFormat);
                    mediaFormat2 = mediaFormat;
                    format2 = format;
                    j4 = j2;
                    j3 = j;
                } else {
                    j3 = j;
                    j4 = j2;
                    format2 = format;
                    mediaFormat2 = mediaFormat;
                }
                VideoFrameMetadataListener videoFrameMetadataListener2 = this.videoFrameMetadataListener;
                if (videoFrameMetadataListener2 != null) {
                    videoFrameMetadataListener2.onVideoFrameAboutToBeRendered(j3, j4, format2, mediaFormat2);
                }
            }

            @Override // androidx.media3.exoplayer.video.spherical.CameraMotionListener
            public void onCameraMotion(long j, float[] fArr) {
                CameraMotionListener cameraMotionListener = this.internalCameraMotionListener;
                if (cameraMotionListener != null) {
                    cameraMotionListener.onCameraMotion(j, fArr);
                }
                CameraMotionListener cameraMotionListener2 = this.cameraMotionListener;
                if (cameraMotionListener2 != null) {
                    cameraMotionListener2.onCameraMotion(j, fArr);
                }
            }

            @Override // androidx.media3.exoplayer.video.spherical.CameraMotionListener
            public void onCameraMotionReset() {
                CameraMotionListener cameraMotionListener = this.internalCameraMotionListener;
                if (cameraMotionListener != null) {
                    cameraMotionListener.onCameraMotionReset();
                }
                CameraMotionListener cameraMotionListener2 = this.cameraMotionListener;
                if (cameraMotionListener2 != null) {
                    cameraMotionListener2.onCameraMotionReset();
                }
            }
        }

        private static final class Api31 {
            public static void registerMediaMetricsListener(final Context context, final ExoPlayerImpl exoPlayerImpl, final boolean z, final PlayerId playerId) {
                exoPlayerImpl.getClock().createHandler(exoPlayerImpl.getPlaybackLooper(), null).post(new Runnable() { // from class: androidx.media3.exoplayer.ExoPlayerImpl$Api31$$ExternalSyntheticLambda0
                    @Override // java.lang.Runnable
                    public final void run() {
                        ExoPlayerImpl.Api31.$r8$lambda$GdNmwbem2h_CgD6K9P4adVimWuQ(context, z, exoPlayerImpl, playerId);
                    }
                });
            }

            public static /* synthetic */ void $r8$lambda$GdNmwbem2h_CgD6K9P4adVimWuQ(Context context, boolean z, ExoPlayerImpl exoPlayerImpl, PlayerId playerId) {
                MediaMetricsListener mediaMetricsListenerCreate = MediaMetricsListener.create(context);
                if (mediaMetricsListenerCreate == null) {
                    Log.w("ExoPlayerImpl", "MediaMetricsService unavailable.");
                    return;
                }
                if (z) {
                    exoPlayerImpl.addAnalyticsListener(mediaMetricsListenerCreate);
                }
                playerId.setLogSessionId(mediaMetricsListenerCreate.getLogSessionId());
            }
        }

        private final class VirtualDeviceIdChangeListener {
            private final WeakReference contextReference;
            private final IntConsumer listener;

            private VirtualDeviceIdChangeListener(Context context) {
                this.contextReference = new WeakReference(context);
                IntConsumer intConsumer = new IntConsumer() { // from class: androidx.media3.exoplayer.ExoPlayerImpl$VirtualDeviceIdChangeListener$$ExternalSyntheticLambda2
                    @Override // java.util.function.IntConsumer
                    public final void accept(int i) {
                        this.f$0.onVirtualDeviceIdChanged(i);
                    }
                };
                this.listener = intConsumer;
                HandlerWrapper handlerWrapperCreateHandler = ExoPlayerImpl.this.clock.createHandler(ExoPlayerImpl.this.applicationLooper, null);
                Objects.requireNonNull(handlerWrapperCreateHandler);
                context.registerDeviceIdChangeListener(new ExoPlayerImpl$VirtualDeviceIdChangeListener$$ExternalSyntheticLambda3(handlerWrapperCreateHandler), intConsumer);
            }

            private void release() {
                Context context = (Context) this.contextReference.get();
                if (context == null) {
                    return;
                }
                context.unregisterDeviceIdChangeListener(this.listener);
            }

            private void onVirtualDeviceIdChanged(int i) {
                if (ExoPlayerImpl.this.playerReleased) {
                    return;
                }
                ExoPlayerImpl.this.sendRendererMessage(1, 19, Integer.valueOf(i));
            }
        }
    }
