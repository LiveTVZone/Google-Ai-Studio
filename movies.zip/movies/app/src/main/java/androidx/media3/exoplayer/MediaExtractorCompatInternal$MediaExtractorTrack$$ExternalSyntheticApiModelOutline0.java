package androidx.media3.exoplayer;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class MediaExtractorCompatInternal$MediaExtractorTrack$$ExternalSyntheticApiModelOutline0 {
}
