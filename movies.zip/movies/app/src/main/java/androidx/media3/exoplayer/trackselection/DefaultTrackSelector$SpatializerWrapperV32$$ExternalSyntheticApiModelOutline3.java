package androidx.media3.exoplayer.trackselection;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class DefaultTrackSelector$SpatializerWrapperV32$$ExternalSyntheticApiModelOutline3 {
}
