package androidx.media3.exoplayer.drm;

import android.media.MediaDrm;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class FrameworkMediaDrm$Api31$$ExternalSyntheticApiModelOutline2 {
    public static /* bridge */ /* synthetic */ MediaDrm.PlaybackComponent m(Object obj) {
        return (MediaDrm.PlaybackComponent) obj;
    }
}
