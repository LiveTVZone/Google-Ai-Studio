package androidx.media3.common.util;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import androidx.media3.common.FlagSet;
import com.google.common.base.Preconditions;
import java.util.ArrayDeque;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArraySet;

/* JADX INFO: loaded from: classes.dex */
public final class ListenerSet {
    private final Clock clock;
    private final ArrayDeque flushingEvents;
    private final IterationFinishedEvent iterationFinishedEvent;
    private final HandlerWrapper iterationFinishedHandler;
    private final CopyOnWriteArraySet listeners;
    private final ArrayDeque queuedEvents;
    private boolean released;
    private final Object releasedLock;
    private final Thread thread;
    private boolean throwsWhenUsingWrongThread;

    public interface Event {
        void invoke(Object obj);
    }

    public interface IterationFinishedEvent {
        void invoke(Object obj, FlagSet flagSet);
    }

    public ListenerSet(Looper looper) {
        this(looper.getThread());
    }

    public ListenerSet(Thread thread) {
        this(new CopyOnWriteArraySet(), null, thread, null, null, true);
    }

    public ListenerSet(Looper looper, Clock clock, IterationFinishedEvent iterationFinishedEvent) {
        this(new CopyOnWriteArraySet(), looper, looper.getThread(), clock, iterationFinishedEvent, true);
    }

    private ListenerSet(CopyOnWriteArraySet copyOnWriteArraySet, Looper looper, Thread thread, Clock clock, IterationFinishedEvent iterationFinishedEvent, boolean z) {
        this.clock = clock;
        this.thread = thread;
        this.listeners = copyOnWriteArraySet;
        this.iterationFinishedEvent = iterationFinishedEvent;
        this.releasedLock = new Object();
        this.flushingEvents = new ArrayDeque();
        this.queuedEvents = new ArrayDeque();
        if (looper != null && clock != null && iterationFinishedEvent != null) {
            this.iterationFinishedHandler = clock.createHandler(looper, new Handler.Callback() { // from class: androidx.media3.common.util.ListenerSet$$ExternalSyntheticLambda0
                @Override // android.os.Handler.Callback
                public final boolean handleMessage(Message message) {
                    return this.f$0.handleMessage(message);
                }
            });
        } else {
            this.iterationFinishedHandler = null;
        }
        this.throwsWhenUsingWrongThread = z;
    }

    public ListenerSet copy(Looper looper, Clock clock, IterationFinishedEvent iterationFinishedEvent) {
        Preconditions.checkState(clock != null || iterationFinishedEvent == null);
        return new ListenerSet(this.listeners, looper, looper.getThread(), clock, iterationFinishedEvent, this.throwsWhenUsingWrongThread);
    }

    public void add(Object obj) {
        Preconditions.checkNotNull(obj);
        synchronized (this.releasedLock) {
            try {
                if (this.released) {
                    return;
                }
                this.listeners.add(new ListenerHolder(obj));
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public void remove(Object obj) {
        verifyCurrentThread();
        for (ListenerHolder listenerHolder : this.listeners) {
            if (listenerHolder.listener.equals(obj)) {
                listenerHolder.release(this.iterationFinishedEvent);
                this.listeners.remove(listenerHolder);
            }
        }
    }

    public void queueEvent(final int i, final Event event) {
        verifyCurrentThread();
        final CopyOnWriteArraySet copyOnWriteArraySet = new CopyOnWriteArraySet(this.listeners);
        this.queuedEvents.add(new Runnable() { // from class: androidx.media3.common.util.ListenerSet$$ExternalSyntheticLambda1
            @Override // java.lang.Runnable
            public final void run() {
                ListenerSet.m6$r8$lambda$MawsDUsVhcg5uFQgolq5mcQJiM(copyOnWriteArraySet, i, event);
            }
        });
    }

    /* JADX INFO: renamed from: $r8$lambda$Maws-DUsVhcg5uFQgolq5mcQJiM, reason: not valid java name */
    public static /* synthetic */ void m6$r8$lambda$MawsDUsVhcg5uFQgolq5mcQJiM(CopyOnWriteArraySet copyOnWriteArraySet, int i, Event event) {
        Iterator it = copyOnWriteArraySet.iterator();
        while (it.hasNext()) {
            ((ListenerHolder) it.next()).invoke(i, event);
        }
    }

    public void flushEvents() {
        verifyCurrentThread();
        if (this.queuedEvents.isEmpty()) {
            return;
        }
        if (this.iterationFinishedEvent != null && !((HandlerWrapper) Preconditions.checkNotNull(this.iterationFinishedHandler)).hasMessages(1)) {
            HandlerWrapper handlerWrapper = this.iterationFinishedHandler;
            handlerWrapper.sendMessageAtFrontOfQueue(handlerWrapper.obtainMessage(1));
        }
        boolean zIsEmpty = this.flushingEvents.isEmpty();
        this.flushingEvents.addAll(this.queuedEvents);
        this.queuedEvents.clear();
        if (zIsEmpty) {
            while (!this.flushingEvents.isEmpty()) {
                ((Runnable) this.flushingEvents.peekFirst()).run();
                this.flushingEvents.removeFirst();
            }
        }
    }

    public void sendEvent(Event event) {
        sendEvent(-1, event);
    }

    public void sendEvent(int i, Event event) {
        queueEvent(i, event);
        flushEvents();
    }

    public void release() {
        verifyCurrentThread();
        synchronized (this.releasedLock) {
            this.released = true;
        }
        Iterator it = this.listeners.iterator();
        while (it.hasNext()) {
            ((ListenerHolder) it.next()).release(this.iterationFinishedEvent);
        }
        this.listeners.clear();
    }

    public void setThrowsWhenUsingWrongThread(boolean z) {
        this.throwsWhenUsingWrongThread = z;
    }

    private boolean handleMessage(Message message) {
        IterationFinishedEvent iterationFinishedEvent = (IterationFinishedEvent) Preconditions.checkNotNull(this.iterationFinishedEvent);
        Iterator it = this.listeners.iterator();
        while (it.hasNext()) {
            ((ListenerHolder) it.next()).iterationFinished(iterationFinishedEvent);
            if (((HandlerWrapper) Preconditions.checkNotNull(this.iterationFinishedHandler)).hasMessages(1)) {
                break;
            }
        }
        return true;
    }

    private void verifyCurrentThread() {
        if (this.throwsWhenUsingWrongThread) {
            Preconditions.checkState(Thread.currentThread() == this.thread);
        }
    }

    private static final class ListenerHolder {
        private FlagSet.Builder flagsBuilder = new FlagSet.Builder();
        public final Object listener;
        private boolean needsIterationFinishedEvent;
        private boolean released;

        public ListenerHolder(Object obj) {
            this.listener = obj;
        }

        private void release(IterationFinishedEvent iterationFinishedEvent) {
            this.released = true;
            if (iterationFinishedEvent == null || !this.needsIterationFinishedEvent) {
                return;
            }
            this.needsIterationFinishedEvent = false;
            iterationFinishedEvent.invoke(this.listener, this.flagsBuilder.build());
        }

        public void invoke(int i, Event event) {
            if (this.released) {
                return;
            }
            if (i != -1) {
                this.flagsBuilder.add(i);
            }
            this.needsIterationFinishedEvent = true;
            event.invoke(this.listener);
        }

        public void iterationFinished(IterationFinishedEvent iterationFinishedEvent) {
            if (this.released || !this.needsIterationFinishedEvent) {
                return;
            }
            FlagSet flagSetBuild = this.flagsBuilder.build();
            this.flagsBuilder = new FlagSet.Builder();
            this.needsIterationFinishedEvent = false;
            iterationFinishedEvent.invoke(this.listener, flagSetBuild);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null || ListenerHolder.class != obj.getClass()) {
                return false;
            }
            return this.listener.equals(((ListenerHolder) obj).listener);
        }

        public int hashCode() {
            return this.listener.hashCode();
        }
    }
}
