package androidx.media3.exoplayer.mediacodec;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class MediaCodecPerformancePointCoverageProvider$Api29$$ExternalSyntheticApiModelOutline3 {
    public static /* bridge */ /* synthetic */ android.media.MediaCodecInfo.VideoCapabilities.PerformancePoint m(Object obj) {
        return (android.media.MediaCodecInfo.VideoCapabilities.PerformancePoint) obj;
    }
}
