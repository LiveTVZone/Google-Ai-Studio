package androidx.media3.exoplayer;

import android.media.MediaRouter2$RouteCallback;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class DefaultSuitableOutputChecker$ImplApi35$$ExternalSyntheticApiModelOutline9 {
    public static /* bridge */ /* synthetic */ MediaRouter2$RouteCallback m(Object obj) {
        return (MediaRouter2$RouteCallback) obj;
    }
}
