package androidx.media3.exoplayer;

import android.media.MediaRouter2$ControllerCallback;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class DefaultSuitableOutputChecker$ImplApi35$$ExternalSyntheticApiModelOutline7 {
    public static /* bridge */ /* synthetic */ MediaRouter2$ControllerCallback m(Object obj) {
        return (MediaRouter2$ControllerCallback) obj;
    }
}
