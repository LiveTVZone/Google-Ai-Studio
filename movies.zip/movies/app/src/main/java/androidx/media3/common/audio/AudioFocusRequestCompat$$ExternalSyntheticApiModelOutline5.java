package androidx.media3.common.audio;

import android.media.AudioFocusRequest;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class AudioFocusRequestCompat$$ExternalSyntheticApiModelOutline5 {
    public static /* bridge */ /* synthetic */ AudioFocusRequest m(Object obj) {
        return (AudioFocusRequest) obj;
    }
}
