package androidx.media3.exoplayer.analytics;

import android.media.metrics.PlaybackErrorEvent;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class MediaMetricsListener$$ExternalSyntheticApiModelOutline3 {
    public static /* synthetic */ PlaybackErrorEvent.Builder m() {
        return new PlaybackErrorEvent.Builder();
    }
}
