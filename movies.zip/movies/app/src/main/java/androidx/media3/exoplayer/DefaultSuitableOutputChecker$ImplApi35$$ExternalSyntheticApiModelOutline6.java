package androidx.media3.exoplayer;

import android.media.MediaRouter2;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class DefaultSuitableOutputChecker$ImplApi35$$ExternalSyntheticApiModelOutline6 {
    public static /* bridge */ /* synthetic */ MediaRouter2 m(Object obj) {
        return (MediaRouter2) obj;
    }
}
