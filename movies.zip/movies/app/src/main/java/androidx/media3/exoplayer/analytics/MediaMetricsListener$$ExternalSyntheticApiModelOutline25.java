package androidx.media3.exoplayer.analytics;

import android.media.metrics.PlaybackMetrics;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class MediaMetricsListener$$ExternalSyntheticApiModelOutline25 {
    public static /* bridge */ /* synthetic */ PlaybackMetrics.Builder m(Object obj) {
        return (PlaybackMetrics.Builder) obj;
    }
}
