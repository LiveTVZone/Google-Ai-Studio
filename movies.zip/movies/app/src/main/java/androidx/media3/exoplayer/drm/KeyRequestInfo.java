package androidx.media3.exoplayer.drm;

import androidx.media3.exoplayer.source.LoadEventInfo;
import com.google.common.collect.ImmutableList;
import java.util.Collection;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final class KeyRequestInfo {
    public final ImmutableList loadInfos;
    public final ImmutableList schemeDatas;

    public static final class Builder {
        private final ImmutableList.Builder loadEventInfos = ImmutableList.builder();
        private ImmutableList schemeDatas;

        public Builder setSchemeDatas(List list) {
            this.schemeDatas = ImmutableList.copyOf((Collection) list);
            return this;
        }

        public Builder addLoadInfo(LoadEventInfo loadEventInfo) {
            this.loadEventInfos.add((Object) loadEventInfo);
            return this;
        }

        public KeyRequestInfo build() {
            return new KeyRequestInfo(this);
        }
    }

    private KeyRequestInfo(Builder builder) {
        this.loadInfos = builder.loadEventInfos.build();
        this.schemeDatas = builder.schemeDatas;
    }
}
