package androidx.media3.exoplayer.analytics;

import android.media.metrics.NetworkEvent;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class MediaMetricsListener$$ExternalSyntheticApiModelOutline1 {
    public static /* synthetic */ NetworkEvent.Builder m() {
        return new NetworkEvent.Builder();
    }
}
