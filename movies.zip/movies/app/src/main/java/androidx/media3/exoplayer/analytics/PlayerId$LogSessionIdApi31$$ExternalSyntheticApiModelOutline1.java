package androidx.media3.exoplayer.analytics;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class PlayerId$LogSessionIdApi31$$ExternalSyntheticApiModelOutline1 {
}
