package androidx.media3.exoplayer.trackselection;

import android.media.Spatializer;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class DefaultTrackSelector$SpatializerWrapperV32$$ExternalSyntheticApiModelOutline4 {
    public static /* bridge */ /* synthetic */ Spatializer m(Object obj) {
        return (Spatializer) obj;
    }
}
