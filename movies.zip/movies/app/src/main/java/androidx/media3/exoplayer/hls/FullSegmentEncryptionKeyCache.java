package androidx.media3.exoplayer.hls;

import android.net.Uri;
import com.google.common.base.Preconditions;
import java.util.LinkedHashMap;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
final class FullSegmentEncryptionKeyCache {
    private final LinkedHashMap backingMap;

    public FullSegmentEncryptionKeyCache(final int i) {
        this.backingMap = new LinkedHashMap(i + 1, 1.0f, false) { // from class: androidx.media3.exoplayer.hls.FullSegmentEncryptionKeyCache.1
            @Override // java.util.LinkedHashMap
            protected boolean removeEldestEntry(Map.Entry entry) {
                return size() > i;
            }
        };
    }

    public byte[] get(Uri uri) {
        if (uri == null) {
            return null;
        }
        return (byte[]) this.backingMap.get(uri);
    }

    public byte[] put(Uri uri, byte[] bArr) {
        return (byte[]) this.backingMap.put((Uri) Preconditions.checkNotNull(uri), (byte[]) Preconditions.checkNotNull(bArr));
    }

    public byte[] remove(Uri uri) {
        return (byte[]) this.backingMap.remove(Preconditions.checkNotNull(uri));
    }
}
