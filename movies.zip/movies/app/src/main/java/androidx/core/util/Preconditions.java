package androidx.core.util;

/* JADX INFO: loaded from: classes.dex */
public abstract class Preconditions {
    public static Object checkNotNull(Object obj) {
        obj.getClass();
        return obj;
    }
}
